# Largest Q-vs-K rank disagreements

This supplement reports the largest disagreements between the percentile rank of the local receiver-conditioned score and the percentile rank of full-dose KL at the primary depth. It is a numerical failure-case audit, not a qualitative token-distribution analysis. The frozen review outputs do not contain complete next-token probability vectors, so the artifact does not reconstruct or invent them after the fact.

The cases below are selected mechanically by absolute percentile-rank gap over the full 4032-pair matrix for each model.

| Model | Host | Donor | Q percentile | KL percentile | Gap | Top-1 flip |
|---|---:|---:|---:|---:|---:|:---:|
| Qwen3-8B | 47 | 19 | 0.902 | 0.109 | 0.793 | no |
| Qwen3-8B | 6 | 27 | 0.892 | 0.158 | 0.734 | no |
| Qwen3-8B | 6 | 17 | 0.926 | 0.199 | 0.727 | no |
| Qwen3-8B | 6 | 36 | 0.856 | 0.153 | 0.703 | no |
| Qwen3-8B | 47 | 10 | 0.868 | 0.179 | 0.689 | no |
| Mistral-7B | 42 | 49 | 0.810 | 0.160 | 0.650 | no |
| Mistral-7B | 58 | 47 | 0.328 | 0.918 | 0.590 | no |
| Mistral-7B | 58 | 23 | 0.167 | 0.748 | 0.581 | no |
| Mistral-7B | 51 | 27 | 0.339 | 0.913 | 0.574 | no |
| Mistral-7B | 42 | 47 | 0.809 | 0.254 | 0.555 | no |

Examples make clear that the high global rank correlation is not an exact finite-step law. In Qwen, some directions receive a high local-Q rank yet produce comparatively small full-dose KL. In Mistral, both over- and under-prediction cases appear. These cases are retained rather than filtered from the reported correlations.

Recompute the selection with:

```bash
python analysis/audit_representative_and_failure_cases.py
```
