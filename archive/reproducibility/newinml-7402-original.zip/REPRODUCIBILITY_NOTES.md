# Reproducibility and reviewer-audit notes

## 1. Frozen confirmatory boundary

The primary downstream-visibility hypothesis was motivated during development on corpus A / an existing causal archive. The confirmatory population and endpoint were then frozen before evaluation on previously held-out corpus B. The frozen protocol is embedded in the Pythia result archive as `FROZEN_SAFE_TRANSFER_PROTOCOL.json` with protocol version `2026-08-17-safe-transfer-v1`.

The primary inferential unit is the independently pretrained Pythia run. Pair-level rows are used only to estimate within-run associations.

## 2. Descriptive safe-rate definition

The safe-rate summaries are descriptive and are not the primary endpoint. A transplant is labeled safe when:

- it does not flip the native top-1 prediction, and
- its KL is at most `0.25 * median(global-donor KL)` for that independently pretrained run.

The frozen protocol also contains 0.10 and 0.50 threshold sweeps. Primary analyses use continuous KL.

## 3. Pre-specified failed finite-step control gate

The frozen protocol specified a same-norm 30-degree rotation of the donor displacement along the local downstream-Fisher descent direction. The intended gate was that the rotation should reduce full-step KL in all six runs.

It did not. Median donor KL across the six runs is approximately 0.17-0.20, while median Fisher-rotation KL is approximately 1.22-1.43. `CLAIM_GATE.csv` records:

`Same-norm downstream-Fisher rotation reduces KL, NOT_SUPPORTED_AS_GATEKEPT_CAUSAL`

This negative result does not contradict the paper's diagnostic claim. It shows that a local quadratic can rank naturally occurring displacements well while a large synthetic step obtained by following the local geometry need not be safe. The paper therefore does not present $Q_{\mathrm{down}}$ as a guaranteed finite-step control objective.

## 4. Context-disjoint LORO audit

The primary LORO test is out-of-run but reuses the same host identities across pretrained runs. `analysis/audit_context_disjoint_loro.py` addresses the reviewer concern using only frozen outputs:

- 10 deterministic splits, seeds `20260820` through `20260829`;
- 128 host identities used for training and the disjoint 128 for testing;
- train on five pretrained runs, test on the held-out run;
- same standardized ridge predictor and manuscript-defined feature sets.

The downstream increment is positive in all 60 held-out run/split evaluations. This is a post-hoc robustness audit, not an additional independent replication.

## 5. Alternative-outcome audit

Because the local Fisher score is derived from KL geometry, `analysis/audit_alternative_outcomes.py` checks outcomes not identical to the primary KL:

- absolute observed-token NLL change: median Spearman with $Q_{\mathrm{down}}$ about 0.477;
- top-1 flip: median ROC-AUC about 0.722;
- LORO prediction of absolute NLL change: median Spearman 0.151 from source geometry and 0.432 after adding $Q_{\mathrm{down}}$, with a positive gain in all six held-out runs.

Again, this is a secondary frozen-output audit.

## 6. Environment and compute disclosure

The main direct physical crossed-receiver V3 experiment ran in FP16 in a Kaggle T4x2 session (two NVIDIA Tesla T4 GPUs, 16 GB VRAM each), with Accelerate sharding, `device_map="balanced"`, a 12,000 MiB per-GPU cap, gradients disabled, 64-token contexts, and pair batch 4.

The preserved V3 summaries cover 12 crossed-receiver stages totaling **131,072 physical interventions** plus the **65,280-pair Mistral full-core** stage. Their instrumented runtimes sum to **631.3 minutes (10.52 hours wall-clock)**: 437.8 minutes for the crossed stages and 193.4 minutes for the full-core stage. The observed end-to-end successful notebook run was approximately **10--12 hours**. With both T4s counted across the measured interval, this is roughly **21 T4 GPU-hours**. See `COMPUTE_V3.md` and `results/physical_crossing_v3/summary/ALL_STAGE_SUMMARIES.csv`.

This V3 figure does not include earlier exploratory development, failed engineering attempts, the earlier 64-by-63 Qwen/Mistral matrix study, or Pythia/small-model scope experiments. Those used additional compute. The earlier matrix-study runtime is preserved separately in `COMPUTE.md`.

Native MLP inputs, native MLP outputs, and native logits are cached once per context; donor displacements are reused across receivers; gradients are disabled. Reviewers can recompute the paper's reported crossed-receiver statistics from the saved row-level CSVs on CPU without rerunning the GPU experiment.

## 7. Review-artifact redistribution boundary

The public-review package excludes full raw C4/WikiText documents and all pretrained model weights. Short C4 excerpts retained from an earlier Pythia manuscript revision remain only as legacy audit material; the current workshop figures do not reproduce those excerpts. Exact token IDs are retained where permitted because they are intervention inputs needed for deterministic reproduction; external token arrays are separated by source license. See `DATA_PROVENANCE.md` and `THIRD_PARTY_NOTICES.md`.


## 8. Fresh-C4 multi-billion replication

The updated workshop manuscript adds a frozen crossed experiment on `Qwen/Qwen3-8B` and `mistralai/Mistral-7B-v0.3`.

- A deterministic C4 validation document pool was selected before model-specific tokenization.
- Each model uses 64 core contexts and all 4032 directed non-self host-donor pairs per tested depth.
- Qwen3-8B is evaluated at relative depths approximately 0.20, 0.40, 0.60, and 0.743.
- Mistral-7B is evaluated at relative depths approximately 0.194, 0.387, 0.613, and 0.742.
- The receiver score uses centered finite differences with frozen epsilon `0.075`.
- Pair-specific association is measured after two-way host/donor residualization and accompanied by a row/column bootstrap.
- A 5,000-draw joint context-label permutation sensitivity test applies the same label permutation to both matrix axes, preserving each context's coupled host/donor role while breaking the observed pairwise alignment.
- The wrong-evaluation control holds the exact donor-host displacement and original transplant outcome fixed while changing only the state used to compute the local sensitivity score. It does not physically inject the fixed displacement into alternative receivers.
- Forward and reverse full-dose KL are additionally compared without interpreting near-zero rank correlation as a complete directional law; the artifact reports both reverse Spearman and larger-to-smaller KL ratios.
- The primary-depth targets additionally include exact-dose, teacher-forced future-propagation, local donor-bank selection, and matched synthetic-direction audits.

The Qwen epsilon audit has minimum pairwise rank stability `0.948739`, narrowly below the frozen `0.95` gate for the `0.04` versus `0.05` comparison. Comparisons involving the chosen `0.075` epsilon are above `0.95`. This miss is retained in the artifact and manuscript.
The derivative estimator was not rerun in FP32; this precision sensitivity is explicitly retained as a limitation rather than inferred away from the FP16 data.

The matched natural-versus-random/rotated direction audit does not support a claim that natural directions are universally more locally linear. The updated paper does not use that hypothesis as a main contribution.

## 9. Fresh-C4 redistribution boundary

The original Kaggle execution material contained the selected raw C4 documents to permit a resumable runtime. Those raw documents are not included in this review package. The artifact retains the frozen protocol, source-pool SHA-256, per-model document hashes, and derived numerical outputs. Reviewers can verify every reported fresh-C4 statistic without raw source text by running `analysis/audit_fresh_c4_multibillion.py`.

## 10. Direct physical crossed-receiver V3 update (2026-08-27)

The earlier workshop experiment changed the state where the predictor was evaluated while holding the measured transplant outcome fixed. V3 closes that causal-design gap by changing the **actual receiver of the intervention**.

For each selected natural origin pair `(i,j)`, V3 forms `delta = U[j] - U[i]`. For each receiver `k`, the notebook patches `U[k] + delta`, recomputes the exact full-dose output metrics, and separately evaluates the receiver-local finite-difference scores for the same fixed `delta`.

Primary-depth replication uses three disjoint deterministic C4 hash buckets. Bucket 1 has 16 receivers per displacement; buckets 2 and 3 have 32. Each stage uses 512 fixed natural displacements. The six primary row-level tables are preserved in `results/physical_crossing_v3/primary/`.

The main within-displacement statistic excludes the origin host and computes Spearman correlation across alternative receivers for each fixed displacement. The paper reports the median across the 512 displacement-level correlations rather than treating every intervention row as an independent replication.

A post-hoc audit found substantial generic receiver susceptibility. To quantify the interaction that remains, `analysis/audit_physical_crossing.py` rank-transforms the outcome and predictor, alternately removes additive `delta_id` and `receiver` means, and correlates the residual ranks. This analysis was not prespecified and is labeled post hoc throughout the revised manuscript.

The V3 paper does not interpret the residual correlation as proving a complete mechanistic theory of compatibility. It establishes that generic receiver fragility is not sufficient to explain the predictive signal under this additive fixed-effect diagnostic.

The direct crossing is also distinct from the next proposed functional-portability experiment. V3 holds a **displacement** fixed and changes its physical receiver; it does not hold an exact donor MLP output fixed and ask whether that output preserves its native causal function.
