# MLP Update Transplant Reproducibility Artifact

Anonymous supplementary artifact for the workshop paper **“Transformer MLP Transplants Depend on the Receiving State.”**

This revision adds the direct physical crossed-receiver experiment that was missing from the earlier submission. The key intervention now holds one naturally occurring MLP displacement fixed and injects that identical displacement into many actual receiver states. The package contains the row-level results needed to verify the new claim without downloading a model.

For the shortest reviewer path, start with [`START_HERE.md`](START_HERE.md).

## What the updated paper establishes

The paper separates three statements that should not be conflated:

1. **Ordinary transplant prediction.** Receiver-conditioned local sensitivity strongly ranks the exact KL caused by a natural donor MLP replacement.
2. **Direct receiver dependence.** When the same natural displacement is physically injected into different receiver states, its full-dose effect changes substantially.
3. **Receiver susceptibility is not the whole story.** Some states are generically fragile, but a post-hoc rank residualization that removes additive displacement and receiver effects leaves a substantial Fisher association in all six primary model x bucket replications.

The artifact does **not** claim that pullback-Fisher geometry is new, or that low KL proves the transplanted computation preserved the function it performed in its source context.

## Fast CPU verification

No GPU or model download is required for the headline results.

```bash
python -m pip install -r requirements.txt
python analysis/audit_physical_crossing.py
python analysis/audit_fresh_c4_multibillion.py
python analysis/audit_simple_downstream_baselines.py
python analysis/audit_joint_context_permutation.py
```

The first script recomputes the six direct physical crossed-receiver results from the row-level CSVs in `results/physical_crossing_v3/primary/`.

Expected primary physical results:

| Model | Bucket | Rows | Fisher pooled rho | Fisher median within-delta rho | Fisher post-hoc residual rho | q_p2 residual rho |
|---|---:|---:|---:|---:|---:|---:|
| Mistral-7B | B1 | 8,192 | .921 | .911 | .664 | .411 |
| Mistral-7B | B2 | 16,384 | .932 | .928 | .675 | .442 |
| Mistral-7B | B3 | 16,384 | .932 | .928 | .658 | .414 |
| Qwen3-8B | B1 | 8,192 | .855 | .871 | .504 | .284 |
| Qwen3-8B | B2 | 16,384 | .871 | .872 | .504 | .292 |
| Qwen3-8B | B3 | 16,384 | .862 | .858 | .520 | .317 |

The residual analysis is explicitly labeled **post hoc** in the manuscript. It rank-transforms the outcome and predictor, removes additive `delta_id` and `receiver` effects by alternating demeaning, then correlates the residual ranks.

## Earlier evidence retained

The updated artifact also preserves the evidence from the earlier workshop revision:

- complete 64 x 63 directed natural-transplant matrices for Qwen3-8B and Mistral-7B at four depths;
- intended-state versus unrelated-state predictor evaluation;
- host/donor two-way residualization;
- exact dose curves;
- held-out host/donor prediction and donor-selection analyses;
- six independently pretrained Pythia/PolyPythias runs;
- negative controls and numerical audits.

A larger 256-context Mistral matrix with 65,280 directed pairs is included at `results/physical_crossing_v3/core/`. Its raw Fisher-KL rho is about `.911`, its host/donor residual rho is `.660`, and the matched `q_p2` residual rho is `.415`.

## Repository layout

- `paper/` - synchronized anonymous paper source, citation-audited NewInML and MusIML PDFs, checklist, and figure assets.
- `analysis/audit_physical_crossing.py` - CPU recomputation of the new direct crossed-receiver headline statistics.
- `analysis/make_physical_crossing_figures.py` - regenerates the new physical-crossing result figures.
- `results/physical_crossing_v3/primary/` - six primary row-level physical-crossing CSVs.
- `results/physical_crossing_v3/core/` - 256-context Mistral complete-pair matrix.
- `results/physical_crossing_v3/summary/` - run configuration, stage summaries, and recomputed compact tables.
- `notebooks/KAGGLE_T4X2_receiver_causal_replication_V3.ipynb` - successful T4x2 physical-crossing execution notebook.
- `results/fresh_c4_qwen3_8b_mistral7b/` - earlier fresh-C4 workshop experiment and controls.
- `results/pythia_six_run/` - independent-pretraining replication evidence.
- `results/external_scope_kaggle_t4/` - earlier architecture-scope checks.
- `figures/` - main and supplementary paper figures.
- `DATA_PROVENANCE.md`, `THIRD_PARTY_NOTICES.md`, `MODEL_REVISIONS.md` - data/model provenance and licensing boundaries.
- `checksums/SHA256SUMS.txt` - integrity manifest.

## Model-level regeneration

The new direct experiment was run with:

- Qwen/Qwen3-8B, primary layer 14;
- mistralai/Mistral-7B-v0.3, primary layer 12;
- 256 contexts per C4 bucket;
- 512 fixed natural displacements;
- 16 receivers/displacement in B1 and 32 in B2/B3;
- centered finite differences with frozen epsilon `0.075`;
- four relative depths near 0.20/0.40/0.60/0.74 for the B1 depth sweep.

The exact successful notebook is in `notebooks/KAGGLE_T4X2_receiver_causal_replication_V3.ipynb`. It expects a Kaggle T4 x2 session and public model/data access. Model weights are not redistributed.

## Paper build

From `paper/`:

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

`main.tex` is the NewInML wrapper. `main_musiml.tex` builds the identical scientific paper with the MusIML workshop label. Both compiled PDFs include the NeurIPS checklist after the references.

## Integrity

From the repository root:

```bash
sha256sum -c checksums/SHA256SUMS.txt
```

The final package contains no author names, personal repository links, Git history, model weights, or full raw C4 documents.

## Final visual synchronization (2026-08-28)

The paper folder is synchronized to the final distribution-first manuscript. Figure 2 now shows raw Bucket-2 alternative-receiver intervention distributions for both 7B/8B models; Figure 3 shows the finite-dose curve; and the Pythia six-run and post-hoc residual results are rendered as native LaTeX tables. `analysis/make_main_text_visuals.py` regenerates the final main-text plots from frozen CSVs.
