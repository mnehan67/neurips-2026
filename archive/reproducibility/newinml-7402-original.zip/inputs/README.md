# Frozen model-level inputs

These files make the paper's model-level intervention protocol reproducible without redistributing raw source documents.

- `pythia_confirmatory_c4_token_ids.zip`: 512 held-out C4-derived Pythia token windows and next-token IDs used by the six-run confirmatory experiment.
- `developmental_causal_numeric_outputs.zip`: four numeric CSVs from the pre-existing developmental causal archive used only by comparison/audit cells; contains no raw text.
- `external_scope/`: exact external-model token windows, separated into `c4/` and `wikitext/` directories so the source licenses remain explicit. `COMMON_SOURCE_MAP.csv` reconstructs the original 512-row order; `COMMON_HOST_INDICES.npy` fixes the 256 hosts.

Raw C4/WikiText text is intentionally not included. Source-specific notices are stored beside the transformed token-ID inputs and inside the Pythia token archive. See `DATA_PROVENANCE.md` and `THIRD_PARTY_NOTICES.md`.
