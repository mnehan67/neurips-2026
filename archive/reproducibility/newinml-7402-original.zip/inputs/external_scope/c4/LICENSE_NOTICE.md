# C4-derived token-ID notice

The `.npy` files in this directory are frozen token-ID transformations of evaluation text drawn from `allenai/c4`. They contain no raw C4 document text.

The current C4 dataset card identifies **ODC-BY 1.0** and states that use is additionally subject to Common Crawl terms of use. C4 was introduced with Raffel et al., *Exploring the Limits of Transfer Learning with a Unified Text-to-Text Transformer* (arXiv:1910.10683 / JMLR 2020).

- ODC-BY 1.0: https://opendatacommons.org/licenses/by/1-0/
- Common Crawl terms: https://commoncrawl.org/terms-of-use
- Source distribution: `allenai/c4`

These token-ID inputs are included only to reproduce the research evaluation. To the extent upstream dataset/content terms apply to these transformed inputs, those terms remain applicable; the repository's author-code license does not replace them.
