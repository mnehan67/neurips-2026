# WikiText-derived token-ID notice

The `.npy` files in this directory are frozen token-ID transformations of evaluation text drawn from `Salesforce/wikitext`. They contain no raw WikiText document text.

Attribution/provenance: Stephen Merity, Caiming Xiong, James Bradbury, and Richard Socher, *Pointer Sentinel Mixture Models* (arXiv:1609.07843).

The current Hugging Face repository is internally inconsistent about the license version: its top-level metadata tags **CC BY-SA 3.0** and **GFDL**, while the dataset-card licensing paragraph states **CC BY-SA 4.0**. This artifact therefore does not silently select a replacement license for these transformed inputs. It preserves attribution, applies no author-code license to them, and treats all applicable upstream terms as controlling.

- CC BY-SA 3.0: https://creativecommons.org/licenses/by-sa/3.0/
- CC BY-SA 4.0: https://creativecommons.org/licenses/by-sa/4.0/
- GNU FDL 1.3: https://www.gnu.org/licenses/fdl-1.3.html
- Source distribution: `Salesforce/wikitext`
