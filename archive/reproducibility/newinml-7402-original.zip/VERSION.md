# Artifact-paper synchronization

This archive packages the final anonymous workshop revision **Transformer MLP Transplants Depend on the Receiving State**.

- Artifact revision date: `2026-08-28`
- Direct-crossing protocol: `RECEIVER_CAUSAL_T4X2_V3`
- V3 random seed: `260826`
- Primary models/layers: Mistral-7B-v0.3 layer 12; Qwen3-8B layer 14
- C4 physical-crossing buckets: `1, 2, 3`
- Contexts per bucket: `256`
- Fixed natural displacements per crossed stage: `512`
- Receivers/displacement: `16` for B1; `32` for B2/B3
- Frozen centered-FD epsilon: `0.075`
- Original workshop fresh-C4 64-context experiment retained unchanged
- Earlier Pythia protocol retained unchanged: `2026-08-17-safe-transfer-v1`

## Final paper revision

The final manuscript uses raw/distribution-first crossed-receiver visuals, a main-text dose curve, a NeurIPS-style residual-association table, and a six-run Pythia replication table. Figure 2 excludes original-host anchor rows so its plotted population matches the paper's within-alternative-receiver statistic. Figure 3 is intentionally rendered slightly smaller for readability.

The scientific main text remains within the 8-page workshop limit. References and the NeurIPS checklist follow the main text. The MusIML wrapper uses the identical scientific source.

## Compute disclosure

Checklist item 8 reports the successful physical-crossing V3 run rather than the earlier 64-by-63 matrix runtime: 131,072 physical interventions plus a 65,280-pair Mistral full-core stage, 631.3 instrumented minutes (10.52 h) and approximately 10--12 h end-to-end on two T4 GPUs.
