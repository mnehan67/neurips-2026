# Compute disclosure: direct physical crossed-receiver V3

The successful V3 execution used a Kaggle session with **two NVIDIA Tesla T4 GPUs (16 GB VRAM each)**. Models were loaded in FP16 with Accelerate sharding using `device_map="balanced"` and a 12,000 MiB per-GPU memory cap. Gradients were disabled; crossed interventions used 64-token contexts and pair batch 4.

The preserved V3 run contains **12 physical crossed-receiver stages**: four bucket-1 depths for each of Mistral-7B-v0.3 and Qwen3-8B, plus bucket-2 and bucket-3 primary-depth replications for both models. Across those stages, the saved summaries record **131,072 physical crossed-receiver interventions**. The run also contains the **65,280-pair Mistral primary-depth full-core** stage.

Instrumented successful-stage runtimes in `ALL_STAGE_SUMMARIES.csv` sum to **631.3 minutes = 10.52 hours of wall-clock stage time**:

- physical crossed-receiver stages: **437.8 minutes = 7.30 hours**;
- Mistral 65,280-pair full-core stage: **193.4 minutes = 3.22 hours**.

Because each 7B--8B model is sharded across both T4s, counting both devices for the full measured interval gives approximately **21 T4 GPU-hours**. The observed end-to-end successful notebook execution was approximately **10--12 hours**, consistent with the instrumented 10.52-hour stage total once model loading, native-state caching, and ordinary session/notebook overhead are included.

This is the compute for the successful V3 run that produced the paper's direct physical-crossing evidence. It is **not** the total compute consumed by the entire research process: earlier exploratory development, failed engineering attempts, the earlier 64-by-63 Qwen/Mistral matrix study, and Pythia/small-model scope experiments used additional compute and are not included in the 10--12 hour figure.

The row-level review artifact is CPU-verifiable; no GPU is needed to recompute the reported correlations, residual analyses, or figures from the saved CSVs.
