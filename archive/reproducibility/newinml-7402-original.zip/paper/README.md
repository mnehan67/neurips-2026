# Paper source

This directory contains the final anonymous workshop manuscript **“Transformer MLP Transplants Depend on the Receiving State.”**

The scientific source is shared by both workshop wrappers:

- `main.tex` / `main_newinml.tex` -> NewInML 2026
- `main_musiml.tex` -> Muslims in ML 2026
- `paper.tex` -> complete manuscript body and preamble
- `checklist.tex` -> NeurIPS checklist appended after the references
- `refs.bib` -> synchronized bibliography
- `figures/` -> final paper figures, including editable TikZ source for Figure 1

Final anonymous review copies:

- `NewInML_Receiver_State_FINAL.pdf`
- `MusIML_Receiver_State_FINAL.pdf`

The scientific content is identical across the two PDFs; only the workshop label differs. The main text remains within the 8-page workshop limit; references and checklist follow.

## Final visual revision

The main paper now uses distribution-first evidence:

- Figure 2 shows the actual Bucket-2 crossed-receiver intervention distributions for Mistral-7B and Qwen3-8B, excluding original-host anchor rows so the visualization matches the within-alternative-receiver statistic.
- Table 1 reports the post-hoc displacement + receiver residual associations in NeurIPS booktabs style.
- Figure 3 promotes the finite-dose curve to the main text.
- Table 2 reports all six independently pretrained Pythia-70M controlled partial correlations.

## Build

For NewInML:

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

For MusIML, replace `main` with `main_musiml`.
