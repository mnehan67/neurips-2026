#!/usr/bin/env python3
from pathlib import Path
import json
import pandas as pd
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
FRESH = ROOT / "results" / "fresh_c4_qwen3_8b_mistral7b"

rows = []
for path in FRESH.glob("*__mlp__*/summary.json"):
    d = json.loads(path.read_text())
    rows.append({
        "model_id": d["model_id"],
        "layer_idx": d["layer_idx"],
        "relative_depth": d["relative_depth"],
        "elapsed_minutes": d["elapsed_minutes"],
        "n_contexts": d["n_contexts"],
        "pair_batch": d["pair_batch"],
    })

observed = pd.DataFrame(rows).sort_values(["model_id", "layer_idx"]).reset_index(drop=True)
expected = pd.read_csv(FRESH / "TARGET_RUNTIME_SUMMARY.csv").sort_values(
    ["model_id", "layer_idx"]
).reset_index(drop=True)

if not np.allclose(observed["elapsed_minutes"], expected["elapsed_minutes"], atol=1e-9):
    raise SystemExit("Runtime summary mismatch")

print("Instrumented MLP target runtime audit passed.")
print(observed.to_string(index=False))
print(f"Total instrumented target runtime: {observed.elapsed_minutes.sum():.1f} min")
