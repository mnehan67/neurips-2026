
from pathlib import Path
import zipfile, tempfile, json
import pandas as pd
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
py_zip = ROOT / 'results' / 'pythia_six_run' / 'pythia_six_run_full_outputs.zip'
sc_zip = ROOT / 'results' / 'external_scope_kaggle_t4' / 'external_scope_derived_outputs.zip'

def unzip_to(zpath, dest):
    with zipfile.ZipFile(zpath) as z:
        z.extractall(dest)

def main():
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        unzip_to(py_zip, td/'py')
        unzip_to(sc_zip, td/'sc')
        pyd = next((td/'py').iterdir())
        scd = next((td/'sc').iterdir())
        prim = pd.read_csv(pyd/'PRIMARY_DOWNSTREAM_VISIBILITY_RUNS.csv')
        loro = pd.read_csv(ROOT/'results'/'secondary_audits'/'LORO_DEFINED_FEATURES.csv')
        scope = pd.read_csv(scd/'summaries'/'MULTIARCH_TARGET_SUMMARIES.csv')
        dose = pd.read_csv(scd/'summaries'/'DOSE_SCOPE_SUMMARY.csv')
        vals = prim.partial_rho_Q_to_KL.to_numpy()
        pivot = loro.pivot(index='heldout_repo', columns='feature_set', values='spearman')
        print('Pythia primary partial rho:', vals.tolist())
        print('Pythia median:', float(np.median(vals)))
        print('Pythia positive:', int((vals > 0).sum()), '/', len(vals))
        print('Exact sign p (two-sided, 6 signs):', 2*(0.5**6))
        print('Paper LORO medians:', {c: float(pivot[c].median()) for c in pivot.columns})
        print('LORO downstream increment median:', float((pivot['source_plus_downstream']-pivot['source_geometry']).median()))
        primary = scope[scope.depth_tag.eq('depth_0p40_PRIMARY')]
        print('External primary partials:', primary[['label','layer','partial_rho_Q_to_KL']].to_dict('records'))
        print('External primary median:', float(primary.partial_rho_Q_to_KL.median()))
        print('All external model-layer positives:', int((scope.partial_rho_Q_to_KL > 0).sum()), '/', len(scope))
        print('External quarter-dose min rho:', float(dose[dose['lambda']==0.25].rho_predicted_actual.min()))
        print('External full-dose min rho:', float(dose[dose['lambda']==1.0].rho_predicted_actual.min()))
if __name__ == '__main__':
    main()
