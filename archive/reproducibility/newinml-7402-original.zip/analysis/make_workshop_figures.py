#!/usr/bin/env python3
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
FRESH = ROOT / "results" / "fresh_c4_qwen3_8b_mistral7b"
OUT = ROOT / "paper" / "figures"
SUPP = ROOT / "figures"
OUT.mkdir(parents=True, exist_ok=True)
SUPP.mkdir(parents=True, exist_ok=True)

rows = []
for path in FRESH.glob("*__mlp__*/summary.json"):
    d = json.loads(path.read_text())
    d["model"] = {
        "Qwen/Qwen3-8B": "Qwen3-8B",
        "mistralai/Mistral-7B-v0.3": "Mistral-7B",
    }.get(d["model_id"], d["model_id"])
    rows.append(d)
summary = pd.DataFrame(rows)
hero = summary[summary["relative_depth"].between(0.37, 0.42)].sort_values("model")
selection = pd.read_csv(FRESH / "SELECTION_SOURCE_ONLY_BASELINE.csv")
dose = pd.read_csv(FRESH / "Q_VS_DOSE_CORRELATIONS.csv")

# Figure 1 is a TikZ schematic. Compile paper/figures/fig1_transplant_and_control_tikz.tex.

# Figure 2: representative raw scatter plus depth robustness.
rep = pd.read_csv(FRESH / "REPRESENTATIVE_HOSTS.csv")
primary_targets = {
    "Qwen3-8B": FRESH / "Qwen_Qwen3-8B__mlp__L14__r0.400" / "pairs.csv",
    "Mistral-7B": FRESH / "mistralai_Mistral-7B-v0.3__mlp__L12__r0.387" / "pairs.csv",
}
qwen_host = int(rep.loc[rep["model"] == "Qwen3-8B", "host"].iloc[0])
qwen_pairs = pd.read_csv(primary_targets["Qwen3-8B"])
qwen_pairs = qwen_pairs[qwen_pairs["host"] == qwen_host].copy()
qwen_pairs["log_q"] = np.log1p(qwen_pairs["q_local"])
qwen_pairs["log_kl"] = np.log1p(qwen_pairs["kl"])
qwen_rho = qwen_pairs[["log_q", "log_kl"]].corr(method="spearman").iloc[0, 1]

fig, axes = plt.subplots(1, 2, figsize=(9.8, 3.55))
ax = axes[0]
ax.scatter(qwen_pairs["log_q"], qwen_pairs["log_kl"], s=22, alpha=0.75)
ax.set_xlabel("$\\log(1+Q_{\\mathrm{down}})$")
ax.set_ylabel("$\\log(1+K)$")
ax.set_title(f"Qwen3-8B host {qwen_host}, $\\rho={qwen_rho:.2f}$")

ax = axes[1]
for model, g in summary.groupby("model"):
    g = g.sort_values("relative_depth")
    y = g["resid_q_rho"].to_numpy()
    lo = g["bootstrap_ci_low"].to_numpy()
    hi = g["bootstrap_ci_high"].to_numpy()
    ax.errorbar(g["relative_depth"], y,
                yerr=np.vstack([y-lo, hi-y]), marker="o", capsize=3, label=model)
ax.set_xlim(0.15, 0.80)
ax.set_ylim(0.2, 0.9)
ax.set_xlabel("Relative depth")
ax.set_ylabel("Pair-specific Spearman correlation")
ax.set_title("Signal survives host/donor controls")
ax.legend(frameon=False, fontsize=8)
fig.tight_layout()
fig.savefig(OUT / "fig2_receiver_specificity.pdf", bbox_inches="tight")
plt.close(fig)

# Figure 3: stronger donor baseline plus direct Q-vs-dose validation.
fig, axes = plt.subplots(1, 2, figsize=(9.8, 3.55))
ax = axes[0]
for model, g in selection.groupby("model"):
    g = g.sort_values("M")
    ax.plot(g["M"], 100*g["q_reduction_vs_source_loo"], marker="o", label=model)
ax.axhline(0, linewidth=0.8)
ax.set_xticks([2, 4, 8, 16, 32])
ax.set_xlabel("Local candidate-bank size")
ax.set_ylabel("Median KL reduction vs source-only selector (%)")
ax.set_title("Receiver-aware donor choice")
ax.legend(frameon=False, fontsize=8)

ax = axes[1]
for model, g in dose.groupby("model"):
    g = g.sort_values("lambda")
    ax.plot(g["lambda"], g["spearman_q_vs_kl"], marker="o", label=model)
ax.set_xticks([0.10, 0.25, 0.50, 0.75, 1.00])
ax.set_ylim(0.78, 1.01)
ax.set_xlabel("Patch dose $\\lambda$")
ax.set_ylabel("Spearman $\\rho(Q,K_\\lambda)$")
ax.set_title("Local ranking remains strong at full dose")
ax.legend(frameon=False, fontsize=8)
fig.tight_layout()
fig.savefig(OUT / "fig3_selection_and_dose.pdf", bbox_inches="tight")
plt.close(fig)

# Supplementary scatter/hexbin so correlations are not shown only as summary bars.
targets = {
    "Qwen3-8B": FRESH / "Qwen_Qwen3-8B__mlp__L14__r0.400" / "pairs.csv",
    "Mistral-7B": FRESH / "mistralai_Mistral-7B-v0.3__mlp__L12__r0.387" / "pairs.csv",
}
fig, axes = plt.subplots(1, 2, figsize=(9.8, 3.6))
for ax, (model, path) in zip(axes, targets.items()):
    d = pd.read_csv(path)
    x = np.log1p(d["q_local"])
    y = np.log1p(d["kl"])
    ax.hexbin(x, y, gridsize=35, mincnt=1)
    rho = pd.DataFrame({"x": x, "y": y}).corr(method="spearman").iloc[0, 1]
    ax.set_xlabel("$\\log(1+Q)$")
    ax.set_ylabel("$\\log(1+K)$")
    ax.set_title(f"{model}, $\\rho={rho:.3f}$")
fig.tight_layout()
fig.savefig(SUPP / "figS1_q_vs_kl_hexbin.pdf", bbox_inches="tight")
plt.close(fig)

print("Workshop and supplementary figures regenerated.")
