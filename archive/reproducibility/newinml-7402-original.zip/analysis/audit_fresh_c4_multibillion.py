#!/usr/bin/env python3
from pathlib import Path
import json
import pandas as pd
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
FRESH = ROOT / "results" / "fresh_c4_qwen3_8b_mistral7b"

summary = pd.read_csv(FRESH / "FRESH_C4_TARGET_SUMMARY.csv")
hero = summary[
    ((summary.model_id == "Qwen/Qwen3-8B") & np.isclose(summary.relative_depth, 0.40, atol=0.02)) |
    ((summary.model_id == "mistralai/Mistral-7B-v0.3") & np.isclose(summary.relative_depth, 0.3870967742, atol=0.02))
].copy()

expected = {
    "Qwen/Qwen3-8B": {
        "raw_q_rho": 0.8665501809385616,
        "resid_q_rho": 0.5631938752093846,
        "correct_receiver_rho": 0.8751122968642708,
        "wrong_receiver_rho": -0.01462833375021406,
        "future_rho_h32": 0.5649949642922542,
    },
    "mistralai/Mistral-7B-v0.3": {
        "raw_q_rho": 0.9105199823682558,
        "resid_q_rho": 0.6766316498809687,
        "correct_receiver_rho": 0.9193744277866787,
        "wrong_receiver_rho": 0.028419090951111236,
        "future_rho_h32": 0.8120422083867422,
    },
}

tol = 1e-10
for model, vals in expected.items():
    row = hero[hero.model_id == model].iloc[0]
    for key, value in vals.items():
        observed = float(row[key])
        if not np.isclose(observed, value, atol=tol, rtol=0):
            raise SystemExit(
                f"Mismatch for {model} {key}: observed={observed} expected={value}"
            )

for _, row in summary.iterrows():
    if not (row["bootstrap_ci_low"] > 0):
        raise SystemExit(
            f"Non-positive bootstrap lower bound: {row.model_id} depth={row.relative_depth}"
        )
    if not (row["resid_q_rho"] >= 0.30):
        raise SystemExit(
            f"Pair-specific gate failed: {row.model_id} depth={row.relative_depth}"
        )

for model, target in [
    ("Qwen/Qwen3-8B", "Qwen_Qwen3-8B__mlp__L14__r0.400"),
    ("mistralai/Mistral-7B-v0.3", "mistralai_Mistral-7B-v0.3__mlp__L12__r0.387"),
]:
    sel = pd.read_csv(FRESH / target / "selection_curves.csv")
    sig = sel[sel["wilcoxon_p"] < 0.05]
    if sig.empty:
        raise SystemExit(f"No significant local-bank selection result for {model}")

print("Fresh-C4 audit passed.")
print(hero[
    [
        "model_id", "raw_q_rho", "resid_q_rho",
        "correct_receiver_rho", "wrong_receiver_rho",
        "receiver_gap", "future_rho_h32",
        "selection_best_reduction", "selection_best_p"
    ]
].to_string(index=False))
