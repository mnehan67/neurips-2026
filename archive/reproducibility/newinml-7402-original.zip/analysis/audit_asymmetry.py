#!/usr/bin/env python3
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
FRESH = ROOT / "results" / "fresh_c4_qwen3_8b_mistral7b"

TARGETS = {
    "Qwen/Qwen3-8B": "Qwen_Qwen3-8B__mlp__L14__r0.400",
    "mistralai/Mistral-7B-v0.3": "mistralai_Mistral-7B-v0.3__mlp__L12__r0.387",
}

rows = []
for model, target in TARGETS.items():
    df = pd.read_csv(FRESH / target / "pairs.csv")
    rev = df[["host", "donor", "kl"]].rename(
        columns={"host": "donor", "donor": "host", "kl": "kl_reverse"}
    )
    sym = df.merge(rev, on=["host", "donor"], how="inner")
    ratio = np.maximum(
        (sym["kl"] + 1e-8) / (sym["kl_reverse"] + 1e-8),
        (sym["kl_reverse"] + 1e-8) / (sym["kl"] + 1e-8),
    )
    rows.append({
        "model_id": model,
        "reverse_spearman": sym[["kl", "kl_reverse"]].corr(method="spearman").iloc[0, 1],
        "median_larger_to_smaller_KL_ratio": float(np.median(ratio)),
        "fraction_ratio_gt_2": float(np.mean(ratio > 2)),
        "fraction_ratio_gt_5": float(np.mean(ratio > 5)),
        "fraction_ratio_gt_10": float(np.mean(ratio > 10)),
    })

observed = pd.DataFrame(rows)
expected = pd.read_csv(FRESH / "ASYMMETRY_SUMMARY.csv")

for col in expected.columns[1:]:
    if not np.allclose(observed[col], expected[col], atol=1e-10, rtol=0):
        raise SystemExit(f"Mismatch in {col}")

print("Asymmetry audit passed.")
print(observed.to_string(index=False))
