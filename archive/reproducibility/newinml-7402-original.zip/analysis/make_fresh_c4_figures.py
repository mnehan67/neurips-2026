#!/usr/bin/env python3
from pathlib import Path
import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
FRESH = ROOT / "results" / "fresh_c4_qwen3_8b_mistral7b"
OUT = ROOT / "paper" / "figures"
OUT.mkdir(parents=True, exist_ok=True)

summary = pd.read_csv(FRESH / "FRESH_C4_TARGET_SUMMARY.csv")
summary["model"] = summary["model_id"].map({
    "Qwen/Qwen3-8B": "Qwen3-8B",
    "mistralai/Mistral-7B-v0.3": "Mistral-7B",
})
hero = summary[summary["relative_depth"].between(0.37, 0.42)].sort_values("model")

x = np.arange(len(hero))
w = 0.34
fig, ax = plt.subplots(figsize=(4.6, 3.2))
ax.bar(x-w/2, hero["correct_receiver_rho"], w, label="Intended evaluation")
ax.bar(x+w/2, hero["wrong_receiver_rho"], w, label="Unrelated evaluation", hatch="//")
ax.axhline(0, linewidth=0.8)
ax.set_xticks(x)
ax.set_xticklabels(hero["model"])
ax.set_ylim(-0.12, 1.0)
ax.set_ylabel("Spearman correlation with full-dose KL")
ax.set_title("The same update is informative only at its receiver")
ax.legend(frameon=False, fontsize=8)
fig.tight_layout()
fig.savefig(OUT / "fig_receiver_specificity.pdf", bbox_inches="tight")
plt.close(fig)

fig, ax = plt.subplots(figsize=(4.6, 3.2))
for model, g in summary.groupby("model"):
    g = g.sort_values("relative_depth")
    y = g["resid_q_rho"].to_numpy()
    lo = g["bootstrap_ci_low"].to_numpy()
    hi = g["bootstrap_ci_high"].to_numpy()
    ax.errorbar(
        g["relative_depth"], y,
        yerr=np.vstack([y-lo, hi-y]),
        marker="o", capsize=3, label=model
    )
ax.axhline(0.30, linestyle="--", linewidth=1, label="Frozen 0.30 gate")
ax.set_xlim(0.15, 0.80)
ax.set_ylim(0.2, 0.9)
ax.set_xlabel("Relative depth")
ax.set_ylabel("Two-way residualized Spearman correlation")
ax.set_title("Pair-specific compatibility persists across depth")
ax.legend(frameon=False, fontsize=8)
fig.tight_layout()
fig.savefig(OUT / "fig_depth_pair_specific.pdf", bbox_inches="tight")
plt.close(fig)

q_sel = pd.read_csv(
    FRESH / "Qwen_Qwen3-8B__mlp__L14__r0.400" / "selection_curves.csv"
)
m_sel = pd.read_csv(
    FRESH / "mistralai_Mistral-7B-v0.3__mlp__L12__r0.387" / "selection_curves.csv"
)
fig, ax = plt.subplots(figsize=(4.6, 3.2))
ax.plot(q_sel["M"], 100*q_sel["median_reduction"], marker="o", label="Qwen3-8B")
ax.plot(m_sel["M"], 100*m_sel["median_reduction"], marker="o", label="Mistral-7B")
ax.axhline(0, linewidth=0.8)
ax.set_xticks([2,4,8,16,32])
ax.set_xlabel("Local candidate-bank size")
ax.set_ylabel("Median KL reduction vs 1NN (%)")
ax.set_title("Receiver-aware selection improves local donor choice")
ax.legend(frameon=False, fontsize=8)
fig.tight_layout()
fig.savefig(OUT / "fig_selection_curve.pdf", bbox_inches="tight")
plt.close(fig)

horizons = [1,4,8,16,32]
fig, ax = plt.subplots(figsize=(4.6, 3.2))
for _, row in hero.iterrows():
    vals = [row[f"future_rho_h{h}"] for h in horizons]
    ax.plot(horizons, vals, marker="o", label=row["model"])
ax.set_xticks(horizons)
ax.set_ylim(0.45, 1.0)
ax.set_xlabel("Teacher-forced future positions")
ax.set_ylabel("Spearman correlation with cumulative KL")
ax.set_title("Receiver sensitivity predicts downstream disturbance")
ax.legend(frameon=False, fontsize=8)
fig.tight_layout()
fig.savefig(OUT / "fig_future_propagation.pdf", bbox_inches="tight")
plt.close(fig)

print("Fresh-C4 figures regenerated.")
