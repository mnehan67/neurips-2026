#!/usr/bin/env python3
"""Regenerate the updated workshop physical-crossing result figures (CPU-only)."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
S = ROOT / "results" / "physical_crossing_v3" / "summary" / "PHYSICAL_CROSSING_PRIMARY_RECOMPUTED.csv"
OUT = ROOT / "figures"
OUT.mkdir(exist_ok=True)

df = pd.read_csv(S)
order = [("mistral",1),("mistral",2),("mistral",3),("qwen",1),("qwen",2),("qwen",3)]
df["key"] = list(zip(df.model, df.bucket))
df = df.set_index("key").loc[order].reset_index(drop=True)
labels = ["M-B1","M-B2","M-B3","Q-B1","Q-B2","Q-B3"]
x=np.arange(6); w=.36

fig, ax=plt.subplots(figsize=(7.2,3.1))
ax.bar(x-w/2,df.q_fisher_median_alt_rho,w,label="Fisher Q")
ax.bar(x+w/2,df.q_p2_median_alt_rho,w,label="q_p2 baseline")
ax.set_xticks(x,labels); ax.set_ylim(0,1); ax.set_ylabel("Median within-delta Spearman rho")
ax.set_title("Same displacement, different actual receivers"); ax.legend(frameon=False,ncol=2,loc="lower left")
fig.tight_layout(); fig.savefig(OUT/"fig2_physical_crossing_recomputed.pdf",bbox_inches="tight"); plt.close(fig)

fig, ax=plt.subplots(figsize=(7.2,3.1))
ax.bar(x-w/2,df.q_fisher_rank_resid_rho,w,label="Fisher Q")
ax.bar(x+w/2,df.q_p2_rank_resid_rho,w,label="q_p2 baseline")
ax.set_xticks(x,labels); ax.set_ylim(0,.8); ax.set_ylabel("Rank residual correlation")
ax.set_title("After displacement + receiver fixed effects"); ax.legend(frameon=False)
fig.tight_layout(); fig.savefig(OUT/"fig3_physical_fixed_effects_recomputed.pdf",bbox_inches="tight"); plt.close(fig)
print("Wrote figures to", OUT)
