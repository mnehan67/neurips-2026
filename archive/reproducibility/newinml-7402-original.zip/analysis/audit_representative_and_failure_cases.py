#!/usr/bin/env python3
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

ROOT = Path(__file__).resolve().parents[1]
FRESH = ROOT / "results" / "fresh_c4_qwen3_8b_mistral7b"
TARGETS = {
    "Qwen3-8B": FRESH / "Qwen_Qwen3-8B__mlp__L14__r0.400" / "pairs.csv",
    "Mistral-7B": FRESH / "mistralai_Mistral-7B-v0.3__mlp__L12__r0.387" / "pairs.csv",
}

rep_rows = []
fail_rows = []
for model, path in TARGETS.items():
    df = pd.read_csv(path).copy()
    host_rhos = []
    for host, g in df.groupby("host"):
        rho = float(spearmanr(np.log1p(g.q_local), np.log1p(g.kl)).statistic)
        host_rhos.append((int(host), rho))
    median_rho = float(np.median([r for _, r in host_rhos]))
    host, rho = min(host_rhos, key=lambda hr: abs(hr[1] - median_rho))
    rep_rows.append({"model": model, "host": host, "host_rho": rho, "median_within_host_rho": median_rho})

    df["q_pct"] = df.q_local.rank(pct=True, method="average")
    df["kl_pct"] = df.kl.rank(pct=True, method="average")
    df["abs_rank_gap"] = (df.q_pct - df.kl_pct).abs()
    for row in df.nlargest(5, "abs_rank_gap").itertuples(index=False):
        fail_rows.append({
            "model": model,
            "host": int(row.host),
            "donor": int(row.donor),
            "q_local": float(row.q_local),
            "kl": float(row.kl),
            "q_percentile": float(row.q_pct),
            "kl_percentile": float(row.kl_pct),
            "abs_rank_gap": float(row.abs_rank_gap),
            "top1_flip": bool(row.top1_flip),
        })

rep = pd.DataFrame(rep_rows)
fail = pd.DataFrame(fail_rows)
exp_rep = pd.read_csv(FRESH / "REPRESENTATIVE_HOSTS.csv")
exp_fail = pd.read_csv(FRESH / "FAILURE_CASE_RANK_AUDIT.csv")

for col in ["host", "host_rho", "median_within_host_rho"]:
    if not np.allclose(rep[col], exp_rep[col], atol=1e-10, rtol=0):
        raise SystemExit(f"Representative-host mismatch in {col}")
for col in ["host", "donor", "q_local", "kl", "q_percentile", "kl_percentile", "abs_rank_gap"]:
    if not np.allclose(fail[col], exp_fail[col], atol=1e-10, rtol=0):
        raise SystemExit(f"Failure-case mismatch in {col}")
print("Representative-host and rank-failure audits passed.")
print(rep.to_string(index=False))
