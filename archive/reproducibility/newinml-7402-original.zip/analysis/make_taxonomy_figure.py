"""Regenerate the source-tangent-mismatch × downstream-visibility taxonomy figure.

The plotted values are the frozen medians reported in the workshop paper.
No model inference is performed.
"""
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'figures' / 'fig4_taxonomy.pdf'

pythia = np.array([[0.423, 0.050], [0.217, 0.000]])
external = np.array([[0.315, 0.000], [0.223, 0.000]])

fig, axes = plt.subplots(1, 2, figsize=(6.35, 2.34), dpi=100)
for ax, data, title in zip(
    axes,
    [pythia, external],
    ['(a) Pythia (six-run median)', '(b) External targets (median)'],
):
    im = ax.imshow(data, cmap='Blues', vmin=0.0, vmax=0.5, aspect='auto')
    ax.set_xticks([0, 1], labels=['Low', 'High'])
    ax.set_yticks([0, 1], labels=['Low', 'High'])
    ax.set_xlabel('Downstream visibility', fontsize=9.5)
    ax.set_ylabel('Source tangent mismatch', fontsize=9.5)
    ax.set_title(title, fontsize=10)
    ax.tick_params(axis='both', labelsize=8.5)
    for r in range(2):
        for c in range(2):
            v = data[r, c]
            ax.text(
                c, r, f'{100*v:.1f}%', ha='center', va='center', fontsize=9,
                color='white' if v >= 0.35 else 'black',
            )
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

cbar = fig.colorbar(im, ax=axes.ravel().tolist(), fraction=0.033, pad=0.035)
cbar.set_label('Safe-transfer rate', fontsize=9.5)
cbar.set_ticks(np.linspace(0, 0.5, 6))
cbar.ax.tick_params(labelsize=8.5)
fig.subplots_adjust(left=0.13, right=0.89, bottom=0.22, top=0.84, wspace=0.42)
fig.savefig(OUT, bbox_inches='tight', pad_inches=0.02)
print(f'Wrote {OUT}')
