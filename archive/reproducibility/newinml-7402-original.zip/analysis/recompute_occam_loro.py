"""Recompute the paper's Occam LORO audit from frozen Pythia pair outputs.

No model inference is performed. The script extracts CONFIRMATORY_B_PAIRS.csv
from the frozen result archive and fits exactly the three feature sets reported
in the NewInML paper:
  1) update magnitude;
  2) + source tangent geometry (state distance, N, A);
  3) + Q_down only.
"""
from pathlib import Path
import tempfile, zipfile
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge

ROOT = Path(__file__).resolve().parents[1]
ZIP = ROOT / 'results' / 'pythia_six_run' / 'pythia_six_run_full_outputs.zip'
OUT = ROOT / 'results' / 'secondary_audits'

FEATURES = {
    'magnitude_only': ['log_update_distance'],
    'source_geometry': [
        'log_update_distance', 'log_state_distance',
        'normalized_nonlinear_residual', 'tangent_alignment'
    ],
    'source_plus_downstream': [
        'log_update_distance', 'log_state_distance',
        'normalized_nonlinear_residual', 'tangent_alignment',
        'log_downstream_Q'
    ],
}


def main():
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        with zipfile.ZipFile(ZIP) as z:
            name = next(n for n in z.namelist() if n.endswith('/CONFIRMATORY_B_PAIRS.csv'))
            z.extract(name, td)
        q = pd.read_csv(td / name)

    q = q[q.condition.eq('knn_5')].copy()
    q['log_update_distance'] = np.log1p(q.exact_update_displacement.clip(lower=0))
    q['log_state_distance'] = np.log1p(q.exact_state_displacement.clip(lower=0))
    q['log_downstream_Q'] = np.log1p(q.downstream_fisher_Q_full.clip(lower=0))
    q['target'] = np.log1p(q.KL.clip(lower=0))

    rows = []
    for held in sorted(q.repo.unique()):
        train0 = q[q.repo.ne(held)].copy()
        test0 = q[q.repo.eq(held)].copy()
        for name, fs in FEATURES.items():
            train = train0[fs + ['target']].replace([np.inf, -np.inf], np.nan).dropna()
            test = test0[fs + ['target']].replace([np.inf, -np.inf], np.nan).dropna()
            model = make_pipeline(StandardScaler(), Ridge(alpha=1.0))
            model.fit(train[fs], train.target)
            pred = model.predict(test[fs])
            rho = float(spearmanr(pred, test.target).statistic)
            rows.append({
                'heldout_repo': held,
                'feature_set': name,
                'n_train': len(train),
                'n_test': len(test),
                'spearman': rho,
            })

    out = pd.DataFrame(rows)
    OUT.mkdir(parents=True, exist_ok=True)
    out.to_csv(OUT / 'LORO_DEFINED_FEATURES.csv', index=False)
    pivot = out.pivot(index='heldout_repo', columns='feature_set', values='spearman')
    pivot.reset_index().to_csv(OUT / 'LORO_DEFINED_FEATURES_WIDE.csv', index=False)
    med = pivot.median()
    delta = pivot['source_plus_downstream'] - pivot['source_geometry']
    print('Paper LORO medians:', {k: float(v) for k, v in med.items()})
    print('Q_down increment median:', float(delta.median()))
    print('Q_down increment positive folds:', int((delta > 0).sum()), '/', len(delta))


if __name__ == '__main__':
    main()
