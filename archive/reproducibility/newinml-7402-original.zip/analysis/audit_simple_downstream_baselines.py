#!/usr/bin/env python3
"""CPU-only audit of simple downstream baselines from frozen Pythia pair outputs.

This is a secondary/post-hoc audit. It does not alter the frozen primary endpoint.
It compares unweighted downstream logit-JVP amplification with the Fisher-weighted
score used in the paper, using the same rank-residualization controls.
"""
from pathlib import Path
import io, zipfile
import numpy as np
import pandas as pd
from scipy.stats import spearmanr, rankdata
from sklearn.linear_model import LinearRegression

ROOT = Path(__file__).resolve().parents[1]
ZIP = ROOT / "results" / "pythia_six_run" / "pythia_six_run_full_outputs.zip"
MEMBER = "mlp_safe_transfer_modal_FULL_ALL_clean_v4_results/CONFIRMATORY_B_PAIRS.csv"

with zipfile.ZipFile(ZIP) as zf:
    q = pd.read_csv(io.BytesIO(zf.read(MEMBER)))
q = q[q.condition.eq("knn_5")].copy()
q["log_update_distance"] = np.log1p(q.exact_update_displacement.clip(lower=0))
q["log_state_distance"] = np.log1p(q.exact_state_displacement.clip(lower=0))
q["log_downstream_Q"] = np.log1p(q.downstream_fisher_Q_full.clip(lower=0))
q["log_logit_jvp_norm"] = np.log1p(q.downstream_logit_jvp_norm.clip(lower=0))
q["logit_gain"] = q.downstream_logit_jvp_norm / np.maximum(q.exact_update_displacement, 1e-12)
q["log_logit_gain"] = np.log1p(q.logit_gain.clip(lower=0))
q["Q_norm"] = q.downstream_fisher_Q_full / np.maximum(q.exact_update_displacement**2, 1e-12)
q["log_Q_norm"] = np.log1p(q.Q_norm.clip(lower=0))

CONTROLS = [
    "log_update_distance",
    "log_state_distance",
    "normalized_nonlinear_residual",
    "tangent_alignment",
]

def partial_spearman(df, x, y="KL", controls=CONTROLS):
    cols = [x, y] + list(controls)
    z = df[cols].replace([np.inf, -np.inf], np.nan).dropna()
    rx, ry = rankdata(z[x]), rankdata(z[y])
    C = np.column_stack([rankdata(z[c]) for c in controls])
    rx -= LinearRegression().fit(C, rx).predict(C)
    ry -= LinearRegression().fit(C, ry).predict(C)
    return float(np.corrcoef(rx, ry)[0, 1])

SCORES = [
    ("update_norm", "log_update_distance", False),
    ("downstream_logit_jvp_norm", "log_logit_jvp_norm", True),
    ("normalized_logit_jvp_gain", "log_logit_gain", True),
    ("fisher_Q", "log_downstream_Q", True),
    ("normalized_fisher_Q", "log_Q_norm", True),
]
rows = []
for repo, g in q.groupby("repo"):
    for name, col, do_partial in SCORES:
        rows.append({
            "repo": repo,
            "baseline": name,
            "n": len(g),
            "raw_spearman": float(spearmanr(g[col], g.KL).statistic),
            "partial_spearman_controls": partial_spearman(g, col) if do_partial else np.nan,
        })
out = pd.DataFrame(rows)
med = out.groupby("baseline")[["raw_spearman", "partial_spearman_controls"]].median().reset_index()
print(med.to_string(index=False))
