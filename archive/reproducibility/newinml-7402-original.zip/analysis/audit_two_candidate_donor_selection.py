#!/usr/bin/env python3
"""Secondary two-candidate donor-selection audit.

Uses only archived pair-level outputs. For every final-checkpoint Pythia host, the
archive contains two precomputed local donors:
  * knn_1: the nearest non-self donor in the frozen PCA-32/Euclidean space;
  * knn_5: the frozen hash-seeded donor sampled uniformly from the first five
    non-self neighbors (the paper's primary 5NN condition).

The audit selects between these two already-evaluated candidates by the lower
Q_down and compares against the nearest donor, the frozen 5NN donor, lower source
mismatch N, and an oracle lower-KL selector. No model rerun or exact KL is used
by the Q_down selector itself.

This is intentionally a proof-of-principle two-candidate audit, not an exhaustive
search over all five neighbors.
"""
from __future__ import annotations

from pathlib import Path
import zipfile
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RESULTS_ZIP = ROOT / "results" / "pythia_six_run" / "pythia_six_run_full_outputs.zip"
OUT_DIR = ROOT / "results" / "secondary_audits"
OUT_DIR.mkdir(parents=True, exist_ok=True)

PAIR_CSV = "mlp_safe_transfer_modal_FULL_ALL_clean_v4_results/CONFIRMATORY_B_PAIRS.csv"


def choose_rows(a: pd.DataFrame, b: pd.DataFrame, choose_a: np.ndarray) -> pd.DataFrame:
    out = a.copy()
    for c in a.columns:
        out[c] = np.where(choose_a, a[c].to_numpy(), b[c].to_numpy())
    return out


with zipfile.ZipFile(RESULTS_ZIP) as zf:
    pairs = pd.read_csv(zf.open(PAIR_CSV))

rows = []
for repo, g in pairs.groupby("repo", sort=True):
    global_median = g.loc[g.condition.eq("global"), "KL"].median()
    safe_threshold = 0.25 * global_median

    nearest = g[g.condition.eq("knn_1")].set_index("source_index").sort_index()
    frozen5 = g[g.condition.eq("knn_5")].set_index("source_index").sort_index()
    common = nearest.index.intersection(frozen5.index)
    nearest = nearest.loc[common]
    frozen5 = frozen5.loc[common]

    if nearest["downstream_fisher_Q_full"].isna().any() or frozen5["downstream_fisher_Q_full"].isna().any():
        raise RuntimeError(f"Missing Q_down for local candidate rows in {repo}")

    lower_q = choose_rows(
        nearest,
        frozen5,
        nearest.downstream_fisher_Q_full.to_numpy()
        <= frozen5.downstream_fisher_Q_full.to_numpy(),
    )
    lower_n = choose_rows(
        nearest,
        frozen5,
        nearest.normalized_nonlinear_residual.to_numpy()
        <= frozen5.normalized_nonlinear_residual.to_numpy(),
    )
    oracle = choose_rows(
        nearest,
        frozen5,
        nearest.KL.to_numpy() <= frozen5.KL.to_numpy(),
    )

    strategies = {
        "nearest": nearest,
        "frozen_5NN": frozen5,
        "lower_source_mismatch": lower_n,
        "lower_Qdown": lower_q,
        "oracle_lower_KL": oracle,
    }

    for strategy, s in strategies.items():
        safe = (s.KL <= safe_threshold) & s.top1_flip.eq(0)
        rows.append(
            {
                "repo": repo,
                "strategy": strategy,
                "n_hosts": len(s),
                "median_KL": s.KL.median(),
                "mean_KL": s.KL.mean(),
                "top1_preservation": s.top1_flip.eq(0).mean(),
                "safe_rate_025x": safe.mean(),
                "safe_threshold": safe_threshold,
            }
        )

run_df = pd.DataFrame(rows)
run_path = OUT_DIR / "TWO_CANDIDATE_DONOR_SELECTION_BY_RUN.csv"
run_df.to_csv(run_path, index=False)

summary = (
    run_df.groupby("strategy", as_index=False)
    .agg(
        median_across_runs_KL=("median_KL", "median"),
        median_across_runs_top1_preservation=("top1_preservation", "median"),
        median_across_runs_safe_rate_025x=("safe_rate_025x", "median"),
    )
)
summary_path = OUT_DIR / "TWO_CANDIDATE_DONOR_SELECTION_SUMMARY.csv"
summary.to_csv(summary_path, index=False)

# Per-run differences for the main non-oracle comparison.
wide = run_df.pivot(index="repo", columns="strategy", values=["median_KL", "safe_rate_025x"])
diff = pd.DataFrame(
    {
        "repo": wide.index,
        "delta_median_KL_lowerQ_minus_nearest": (
            wide[("median_KL", "lower_Qdown")] - wide[("median_KL", "nearest")]
        ).to_numpy(),
        "delta_safe_rate_lowerQ_minus_nearest": (
            wide[("safe_rate_025x", "lower_Qdown")] - wide[("safe_rate_025x", "nearest")]
        ).to_numpy(),
    }
)
diff_path = OUT_DIR / "TWO_CANDIDATE_DONOR_SELECTION_DIFFS.csv"
diff.to_csv(diff_path, index=False)

print(summary.to_string(index=False, float_format=lambda x: f"{x:.6f}"))
print("\nLower-Q_down vs nearest: median KL improved in", int((diff.delta_median_KL_lowerQ_minus_nearest < 0).sum()), "/", len(diff), "runs")
print("Lower-Q_down vs nearest: safe rate improved in", int((diff.delta_safe_rate_lowerQ_minus_nearest > 0).sum()), "/", len(diff), "runs")
print("Wrote:", run_path)
print("Wrote:", summary_path)
print("Wrote:", diff_path)
