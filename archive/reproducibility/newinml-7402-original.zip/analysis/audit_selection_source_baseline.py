#!/usr/bin/env python3
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from scipy.stats import wilcoxon

ROOT = Path(__file__).resolve().parents[1]
FRESH = ROOT / "results" / "fresh_c4_qwen3_8b_mistral7b"
TARGETS = {
    "Qwen3-8B": FRESH / "Qwen_Qwen3-8B__mlp__L14__r0.400",
    "Mistral-7B": FRESH / "mistralai_Mistral-7B-v0.3__mlp__L12__r0.387",
}

rows = []
for model, tdir in TARGETS.items():
    d = pd.read_csv(tdir / "pairs.csv")
    d["log_kl"] = np.log1p(d["kl"])
    d["log_du"] = np.log1p(d["du_norm"])
    d["log_dm"] = np.log1p(d["dm_norm"])
    features = ["log_du", "log_dm", "source_N", "source_A", "state_dist_pca"]
    d["source_pred"] = np.nan

    for host in sorted(d["host"].unique()):
        train = d[d["host"] != host]
        test = d[d["host"] == host]
        Xtr = train[features].replace([np.inf, -np.inf], np.nan).fillna(0).to_numpy()
        Xte = test[features].replace([np.inf, -np.inf], np.nan).fillna(0).to_numpy()
        model_fit = make_pipeline(StandardScaler(), Ridge(alpha=1.0))
        model_fit.fit(Xtr, train["log_kl"].to_numpy())
        d.loc[test.index, "source_pred"] = model_fit.predict(Xte)

    for M in [2, 4, 8, 16, 32]:
        chosen = []
        for host, g in d.groupby("host"):
            bank = g.nsmallest(M, "state_dist_pca")
            chosen.append({
                "host": int(host),
                "kl_1nn": float(bank.loc[bank["state_dist_pca"].idxmin(), "kl"]),
                "kl_q": float(bank.loc[bank["q_local"].idxmin(), "kl"]),
                "kl_source_loo": float(bank.loc[bank["source_pred"].idxmin(), "kl"]),
            })
        c = pd.DataFrame(chosen)
        med1 = float(c["kl_1nn"].median())
        medq = float(c["kl_q"].median())
        meds = float(c["kl_source_loo"].median())
        rows.append({
            "model": model,
            "M": M,
            "median_kl_1nn": med1,
            "median_kl_source_loo": meds,
            "median_kl_q": medq,
            "q_reduction_vs_1nn": (med1 - medq) / med1,
            "q_reduction_vs_source_loo": (meds - medq) / meds,
            "p_q_less_source_loo": float(wilcoxon(c["kl_q"], c["kl_source_loo"], alternative="less").pvalue),
            "p_q_less_1nn": float(wilcoxon(c["kl_q"], c["kl_1nn"], alternative="less").pvalue),
        })

observed = pd.DataFrame(rows)
expected = pd.read_csv(FRESH / "SELECTION_SOURCE_ONLY_BASELINE.csv")
cols = [c for c in observed.columns if c not in {"model"}]
if observed[["model", "M"]].to_dict("records") != expected[["model", "M"]].to_dict("records"):
    raise SystemExit("Model/bank ordering mismatch")
for col in cols:
    if not np.allclose(observed[col].astype(float), expected[col].astype(float), atol=1e-10, rtol=0):
        raise SystemExit(f"Mismatch in {col}")

print("Held-out source-only donor-selector audit passed.")
print(observed.to_string(index=False))
