"""Regenerate the final main-text distribution and dose-curve figures from frozen CSVs."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import spearmanr

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures"
OUT.mkdir(exist_ok=True)

cases = [
    (ROOT / "results/physical_crossing_v3/primary/mistral_b2_layer12_cross_receiver_physical.csv",
     "Mistral-7B", "layer 12 (~39% depth)", OUT / "fig2_mistral_b2_hexbin.png"),
    (ROOT / "results/physical_crossing_v3/primary/qwen_b2_layer14_cross_receiver_physical.csv",
     "Qwen3-8B", "layer 14 (~40% depth)", OUT / "fig2_qwen_b2_hexbin.png"),
]

for path, model, layer, out_path in cases:
    df = pd.read_csv(path)
    # Match the paper's primary crossed-receiver statistic: alternative receivers only.
    df = df[df["receiver"] != df["origin_host"]].copy()
    pooled = spearmanr(df["q_fisher"], df["kl_cross"]).statistic
    within = []
    for _, g in df.groupby("delta_id"):
        r = spearmanr(g["q_fisher"], g["kl_cross"]).statistic
        if np.isfinite(r):
            within.append(r)
    median_within = float(np.median(within))

    floor = 1e-8  # display-only floor for numerical zeros
    x = np.log10(np.maximum(df["q_fisher"].to_numpy(), floor))
    y = np.log10(np.maximum(df["kl_cross"].to_numpy(), floor))

    fig, ax = plt.subplots(figsize=(6.0, 4.25))
    hb = ax.hexbin(x, y, gridsize=56, mincnt=1, bins="log")
    cb = fig.colorbar(hb, ax=ax)
    cb.set_label("Alternative-receiver interventions per hexagon (log count)")
    ax.set_xlabel(r"Receiver-local score $\log_{10} Q_k(\Delta u)$")
    ax.set_ylabel(r"Measured full-dose effect $\log_{10} K_k$")
    ax.set_title(f"{model}: same displacement, different receivers")
    ax.text(
        0.04, 0.96,
        f"Bucket 2 · {layer}\n"
        f"n = {len(df):,} alternative-receiver interventions\n"
        f"pooled Spearman rho = {pooled:.3f}\n"
        f"median within-delta rho = {median_within:.3f}",
        transform=ax.transAxes, va="top",
        bbox=dict(boxstyle="round", alpha=0.85),
    )
    fig.tight_layout()
    fig.savefig(out_path, dpi=240, bbox_inches="tight")
    plt.close(fig)

# Dose curve
q = pd.read_csv(ROOT / "results/fresh_c4_qwen3_8b_mistral7b/Q_VS_DOSE_CORRELATIONS.csv")
fig, ax = plt.subplots(figsize=(6.4, 4.4))
for model in ["Mistral-7B", "Qwen3-8B"]:
    d = q[q["model"] == model].sort_values("lambda")
    ax.plot(d["lambda"], d["spearman_q_vs_kl"], marker="o", linewidth=2, label=model)
ax.set_xlabel(r"Patch dose $\lambda$")
ax.set_ylabel(r"Spearman $\rho(Q_{\mathrm{recv}}, K_\lambda)$")
ax.set_title("Local ranking remains strong as the transplant reaches full dose")
ax.set_xticks(sorted(q["lambda"].unique()))
ax.set_ylim(0.80, 1.00)
ax.legend()
ax.grid(alpha=0.25)
fig.tight_layout()
fig.savefig(OUT / "fig3_dose_curve.png", dpi=240, bbox_inches="tight")
plt.close(fig)
