# Compute disclosure for the earlier 64-by-63 C4 matrix study

> **Scope note.** This file documents the earlier Qwen3-8B/Mistral-7B 64-by-63 matrix study. It is not the compute disclosure for the paper's newer physical crossed-receiver contribution. For the successful V3 run (131,072 physical interventions plus the 65,280-pair Mistral full-core stage; 10.52 instrumented hours and about 10--12 hours end-to-end on T4x2), see `COMPUTE_V3.md`.

The completed newly sampled C4 study ran in a Kaggle session with two NVIDIA T4 GPUs with 16 GB VRAM each. Models were loaded in FP16 using Accelerate sharding. No gradients were computed and the forward passes used short 64-token contexts.

The saved `summary.json` files contain instrumented elapsed time for every completed MLP target. The eight completed model-depth targets total **134.9 minutes** of target runtime:

- Qwen3-8B, four depths: **70.2 minutes**
- Mistral-7B-v0.3, four depths: **64.7 minutes**

The ordinary depth targets take about 14--15 minutes end to end, including native-state caching and the complete 64-by-63 crossed matrix. The primary-depth targets take about 22--25 minutes because they additionally run the wrong-evaluation, exact-dose, future-position, epsilon, donor-selection, and synthetic-direction audits.

This number is not the total compute used by the research project. It excludes model checkpoint download and setup time, failed attention and larger-model attempts, artifact packaging, and exploratory development.

The target runtime is lower than a naive estimate that reruns an independent full forward pass from scratch for every donor-host pair because the implementation caches each context's native MLP input, native MLP output, and native logits once, reuses each donor update across all hosts, batches four donor interventions at a time for the 7B--8B models, and disables gradients and KV caching.

The exact per-target measurements are in:

`results/fresh_c4_qwen3_8b_mistral7b/TARGET_RUNTIME_SUMMARY.csv`

They can be reconstructed from the frozen target summaries with:

```bash
python analysis/audit_compute_runtime.py
```
