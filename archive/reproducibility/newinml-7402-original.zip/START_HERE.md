# Start here

This artifact supports **“Transformer MLP Transplants Depend on the Receiving State.”**

## The one idea

A natural MLP displacement does not have one fixed downstream effect independent of where it is inserted.

For a natural origin pair, define the displacement

`delta_u = donor_update - origin_host_update`.

The new experiment freezes that exact vector and injects it into many different receiver states:

`receiver_update -> receiver_update + delta_u`.

Only the receiver changes. We then recompute the exact full-dose next-token KL and the local receiver-conditioned sensitivity score at every receiver.

Across Qwen3-8B and Mistral-7B, a local receiver-side Fisher score strongly ranks which receivers are most affected. The effect replicates across three disjoint C4 buckets at the primary depth and across four depths in the first bucket.

## The important qualification

Some receivers are generically fragile: they tend to react strongly to many perturbations. Therefore, the very high raw within-displacement correlations are not interpreted as pure pair-specific compatibility.

A post-hoc rank residual analysis removes additive fixed-displacement and receiver effects. Fisher still has residual correlations of roughly `.50-.68` across all six primary replications, compared with `.28-.44` for the matched `q_p2` downstream baseline.

## Fastest verification

```bash
python -m pip install -r requirements.txt
python analysis/audit_physical_crossing.py
```

This uses only the frozen row-level CSVs and prints the six primary rows reported by the updated paper.

Then, if desired:

```bash
python analysis/make_physical_crossing_figures.py
python analysis/audit_fresh_c4_multibillion.py
python analysis/audit_joint_context_permutation.py
python analysis/audit_simple_downstream_baselines.py
```

## Where the new data are

- `results/physical_crossing_v3/primary/` - six row-level primary physical-crossing files.
- `results/physical_crossing_v3/core/` - large 256-context Mistral complete-pair matrix.
- `results/physical_crossing_v3/summary/` - configuration and compact summaries.
- `notebooks/KAGGLE_T4X2_receiver_causal_replication_V3.ipynb` - successful GPU execution notebook.
- `paper/` - updated manuscript and figures.

## What is still open

The experiment measures **disturbance**: how much a fixed transplant changes the receiver's output distribution.

It does not yet establish **functional portability**: whether an exact natural donor MLP output preserves the causal function it performed in its original context when moved elsewhere. The paper keeps that question open rather than treating low KL as successful computation reuse.
