# Transformer MLP Transplants Depend on the Receiving State

Public reproducibility repository for **“Transformer MLP Transplants Depend on the Receiving State”** by **Muhammed Nehan (Ajman University)**, accepted to the **NewInML** and **MusIML** workshops at NeurIPS 2026.

This release accompanies the public workshop versions of the paper. It contains the crossed-receiver experiments, the control-panel and receiver-transformation analyses, the paper sources and figures, and CPU audit scripts.

## Main findings

The repository supports four distinct empirical statements:

1. **Fixed updates have receiver-dependent effects.** A natural MLP displacement is held fixed and physically injected into many natural receiver states. Its exact full-dose next-token KL varies substantially across receivers.
2. **Receiver-local output sensitivity ranks those effects.** Across six primary crossed-receiver replications, the median within-fixed-displacement Spearman correlation is `0.858–0.928`.
3. **Generic receiver fragility is not the whole story.** After removing additive displacement and receiver effects, Fisher residual rank correlations remain `0.504–0.675`, above the matched `q_p2` baseline (`0.284–0.442`). A rank-KL decomposition leaves `18–25%` non-additive residual variation across the six crossed matrices.
4. **Receiver state also changes the direction of the downstream causal effect.** On a separate 96-displacement × 8-receiver panel, receiver-specific rank-16 maps trained on 72 displacements predict the causal direction of 24 held-out displacements better than a global or wrong-receiver map in both Qwen3-8B and Mistral-7B.

The paper uses pullback-Fisher geometry as **established diagnostic machinery**; it does not claim that Fisher geometry itself is new.

## Fastest CPU verification

No model download or GPU is required to verify the main reported statistics from frozen outputs.

```bash
python -m pip install -r requirements.txt
python analysis/audit_physical_crossing.py
python analysis/audit_rank_variance_decomposition.py
python analysis/audit_receiver_transformation.py
```

Or run the consolidated audit:

```bash
python analysis/audit_final_public_results.py
```

Paper figures, the spread statistic, and the numerical audit:

```bash
python analysis/make_paper_figures.py --repo . --out /tmp/paper_figures
python analysis/derived_stats.py --repo .
python analysis/verify_fp32_suffix_jvp_audit.py --audit results/fp32_suffix_jvp_audit --repo .
```

Expected headline values include:

| Model | Final receiver-map cosine | Global map | Wrong-receiver map | Receiver-map − global (95% CI) |
|---|---:|---:|---:|---:|
| Qwen3-8B | 0.316 | 0.086 | -0.023 | +0.230 [0.205, 0.256] |
| Mistral-7B | 0.241 | 0.109 | 0.028 | +0.132 [0.108, 0.155] |

## Repository layout

- `paper/NewInML_2026/` — complete public NewInML source, official NeurIPS 2026 style, figures, references, appendices, and checklist.
- `paper/MusIML_2026/` — identical scientific paper with the MusIML workshop wrapper.
- `paper/*.pdf` — compiled public versions.
- `results/physical_crossing_v3/` — six primary crossed-receiver row-level tables plus the 65,280-pair Mistral complete matrix.
- `results/receiver_transformation_v1/` — final Qwen/Mistral control-panel, trajectory, held-out map, bootstrap, and numerical-audit outputs.
- `results/fresh_c4_qwen3_8b_mistral7b/` — ordinary 64×63 transplant matrices and controls.
- `results/pythia_six_run/` — six independently pretrained Pythia/PolyPythias replications.
- `results/fp32_suffix_jvp_audit/` — exact FP32 downstream-suffix JVP audit outputs and FP16-vs-FP32 comparison.
- `results/derived/` — descriptive spread statistic used in the paper (from `analysis/derived_stats.py`).
- `analysis/` — CPU verification and figure-generation scripts (`make_paper_figures.py` regenerates every data figure of the paper).
- `notebooks/` — successful large-model execution notebooks and optional numerical-audit notebook.
- `inputs/` — frozen token-ID inputs and provenance metadata where redistribution is permitted.
- `checksums/SHA256SUMS.txt` — integrity manifest for this release.

## Primary crossed-receiver results

| Model | Bucket | Rows | Median within-Δ Fisher ρ | Residual Fisher ρ | Residual `q_p2` ρ |
|---|---:|---:|---:|---:|---:|
| Mistral-7B | B1 | 8,192 | 0.911 | 0.664 | 0.411 |
| Mistral-7B | B2 | 16,384 | 0.928 | 0.675 | 0.442 |
| Mistral-7B | B3 | 16,384 | 0.928 | 0.658 | 0.414 |
| Qwen3-8B | B1 | 8,192 | 0.871 | 0.504 | 0.284 |
| Qwen3-8B | B2 | 16,384 | 0.872 | 0.504 | 0.292 |
| Qwen3-8B | B3 | 16,384 | 0.858 | 0.520 | 0.317 |

The residual analysis is post hoc. It rank-transforms outcome and predictor, removes additive displacement and receiver effects by alternating demeaning, then correlates the residual ranks.

## Final control panel

The 96×8 panel compares the receiver-local Fisher score with stronger alternatives:

| Model | Fisher | AtP top-token | AtP margin | `q_p2` | `||Δu||/||r||` | `|cos(Δu,r)|` |
|---|---:|---:|---:|---:|---:|---:|
| Qwen3-8B | 0.738 | 0.500 | 0.429 | 0.226 | 0.071 | -0.012 |
| Mistral-7B | 0.905 | 0.750 | 0.179 | 0.060 | 0.000 | 0.048 |

Entries are median within-fixed-displacement Spearman correlations with exact full-dose KL. The physical equal-norm control preserves receiver ordering in both models (`ρ = 1.000`).

## Numerical validation

The crossed experiments estimate the directional response by centered finite differences (`eps = 0.075`) on FP16 model evaluations. Two audits on the same 16 frozen cases per model (control-panel displacements 0–15 at receiver 0) are included:

1. **End-to-end FP16 step-size stability** (`results/receiver_transformation_v1/*/finite_difference_richardson.csv`): half-step and Richardson comparisons, which combine step, FP16-precision, and native-probability effects.
2. **Exact FP32 downstream-suffix JVP closure** (`results/fp32_suffix_jvp_audit/`): natural states from the FP16 model are cached and the downstream suffix is recomputed in FP32. FP32 finite differences match exact FP32 JVPs (median cosine 1.0000, Spearman 1.000, median relative Q error 0.21% / 0.20%), while FP16 scores for the same 16 cases agree less closely with the exact FP32 scores (Spearman 0.785 / 0.544; median relative difference 21.6% / 26.7%).

Truncation error at `eps = 0.075` is negligible on the tested directions; on this audit panel the pattern is consistent with finite-precision effects dominating the observed discrepancy. The FP16 Fisher values are therefore used as ranking diagnostics, not exact FP32 quadratic forms; the primary crossed result is an empirical association between the computed score and the measured full-dose KL. The audit is not a full-model FP32 JVP, and it varies displacement direction at a fixed receiver, so it does not reproduce the primary within-displacement receiver-ranking statistic. `notebooks/optional_exact_fp32_jvp_audit.ipynb` (full-model FP32 on one 80 GB GPU) was not executed and is not part of the reported results. Verify with `python analysis/verify_fp32_suffix_jvp_audit.py --audit results/fp32_suffix_jvp_audit`.

## Model-level regeneration

The successful crossed-receiver run used Kaggle **T4 ×2**, FP16 model weights, Accelerate sharding, 64-token contexts, and small pair batches. The final receiver-transformation experiments use the same hardware class and store only final-token causal differences for downstream layers.

See `COMPUTE_V3.md`, `REPRODUCIBILITY_NOTES.md`, and `results/receiver_transformation_v1/README.md` for details.

## Paper builds

### NewInML

```bash
cd paper/NewInML_2026
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

### MusIML

```bash
cd paper/MusIML_2026
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

Both use the official NeurIPS 2026 style and include the technical appendices and NeurIPS checklist.

## Scope and limitations

The primary outcome is next-token distributional disturbance, not semantic functional preservation. The main large-model evidence is MLP-only and uses Qwen3-8B and Mistral-7B-v0.3. The learned receiver maps capture a reproducible component of causal-direction change, not the entire update–receiver interaction. The large-scale Fisher scores are FP16 finite differences used as ranking diagnostics; the FP32 downstream-suffix audit closes truncation error on the tested directions without making them numerically exact.

## Data and model redistribution

This repository does not redistribute pretrained model weights or full raw C4/WikiText documents. It contains author-created code, derived numerical outputs, frozen token IDs where permitted, and source/provenance metadata. See `DATA_PROVENANCE.md`, `THIRD_PARTY_NOTICES.md`, and `MODEL_REVISIONS.md`.

## Author

**Muhammed Nehan**  
Ajman University  
202410365@ajmanuni.ac.ae

## License

Author-created code is released under the MIT License as scoped in `LICENSE_CODE.md`. Third-party data, model, template, and asset terms remain controlling for their respective materials.
