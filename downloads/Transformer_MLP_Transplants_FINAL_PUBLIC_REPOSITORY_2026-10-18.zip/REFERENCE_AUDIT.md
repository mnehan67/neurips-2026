# Reference and positioning audit

The workshop bibliography was re-audited on 2026-08-28 against primary venue pages, ACL Anthology, PMLR, JMLR, ICLR proceedings/OpenReview, and original arXiv records. The public manuscript cites **40 distinct works** and the synchronized `paper/NewInML_2026/refs.bib` and `paper/MusIML_2026/refs.bib` contains exactly those **40 cited entries**. Unused BibTeX entries were removed. The compiled paper has no unresolved citation keys.

## 2025--2026 metadata recheck

Every 2025--2026 work cited by the manuscript was individually checked against a primary or first-party record. The checked set is:

- van der Wal et al. (2025), **PolyPythias**, ICLR 2025 — https://proceedings.iclr.cc/paper_files/paper/2025/hash/d611d06e3207330555fbc10810e70163-Abstract-Conference.html
- Geiger et al. (2025), **Causal Abstraction**, JMLR 26(83):1--64 — https://jmlr.org/papers/v26/23-0058.html
- Dong et al. (2025), **CONTRANS**, COLING 2025 — https://aclanthology.org/2025.coling-main.279/
- Yang et al. (2025), **Qwen3 Technical Report**, arXiv:2505.09388 — https://arxiv.org/abs/2505.09388
- Opiełka, Rosenbusch, and Stevenson (2026), **Causality != Invariance**, ICLR 2026 — https://openreview.net/forum?id=LmLmhb6GEL
- Grant et al. (2026), **Addressing Divergent Representations from Causal Interventions on Neural Networks**, ICLR 2026 — https://openreview.net/forum?id=cZrTMqYVL6
- Li, Li, and Huang (2026), **Steering Vector Fields**, arXiv:2602.01654 — https://arxiv.org/abs/2602.01654
- Park, Nief, Choe, and Veitch (2026), **The Information Geometry of Softmax**, ICML 2026 — https://arxiv.org/abs/2602.15293
- Skifstad, Yang, and Chou (2026), **Local Linearity of LLMs Enables Activation Steering via Model-Based Linear Optimal Control**, ICML 2026 — https://arxiv.org/abs/2604.19018
- Garcia (2026), **No Free Swap**, arXiv:2605.16234 — https://arxiv.org/abs/2605.16234
- Wang and Zhao (2026), **FishBack**, arXiv:2605.17231 — https://arxiv.org/abs/2605.17231
- Olivieri and Pérez Rodríguez (2026), **Transformer Field Theory**, arXiv:2605.25225 — https://arxiv.org/abs/2605.25225
- Quirke (2026), **Necessary, Decodable and Reversible, Yet Not Transferable**, arXiv:2606.08292 — https://arxiv.org/abs/2606.08292
- Vaidyanathan et al. (2026), **The Curse of Multiple Mediators**, arXiv:2606.27510 — https://arxiv.org/abs/2606.27510
- Ma et al. (2026), **Hidden APIs in Language Models**, arXiv:2607.27617 — https://arxiv.org/abs/2607.27617

### FishBack correction

The authoritative current arXiv record for `2605.17231` lists **Sihan Wang and Jiayi Zhao**. Some secondary indexes list a five-author record; the paper and artifact use the two-author arXiv record.


### Activation Addition metadata

The citation for arXiv:2308.10248 follows the current arXiv record, **Steering Language Models With Activation Engineering**, rather than the title of earlier arXiv versions.

## Closest causal-intervention and transplant precedents

- Vig et al. (NeurIPS 2020), causal mediation analysis in language models.
- Geiger et al. (NeurIPS 2021; JMLR 2025), interchange interventions and causal abstraction.
- Goldowsky-Dill et al. (2023), path patching.
- Conmy et al. (NeurIPS 2023), automated circuit discovery with activation patching.
- Zhang and Nanda (ICLR 2024), activation-patching metrics and methodology.
- Ghandeharioun et al. (ICML 2024), Patchscopes.
- Pal et al. (CoNLL 2023), Future Lens.
- Wang, Whyte, and Xu (Findings ACL 2024), relational hidden-state transplantation.
- Dong et al. (COLING 2025), CONTRANS concept transplantation.
- Quirke (2026), a stress test showing that attention-head role evidence need not imply cross-prompt transfer.
- Garcia (2026), protocol-dependent layer interchangeability.
- Vaidyanathan et al. (2026), interaction effects in activation patching.
- Grant et al. (ICLR 2026), harmless versus pernicious intervention-induced divergence.
- Ma et al. (2026), reusable causal interfaces and transplantation from forked futures.

## Activation steering and representation geometry

Static activation addition and contrastive steering establish useful intervention directions, but later work complicates a purely context-invariant or Euclidean interpretation. Opiełka et al. separate causality from format invariance; Steering Vector Fields makes the intervention direction explicitly state dependent; Park et al. grounds geometry in output distributions; FishBack pulls softmax Fisher geometry through downstream Jacobians; Skifstad et al. uses state-local Jacobian dynamics for feedback steering. The present paper therefore does **not** claim that context dependence or pullback-Fisher geometry is new.

## How the present claim remains distinct

The public paper no longer relies on the wrong-evaluation-state diagnostic as its strongest receiver-dependence evidence. It now performs the direct physical experiment: an **example-specific natural MLP displacement is held fixed and injected into many actual receiver states**, with the full-dose outcome recomputed at every receiver. The empirical contribution is that these crossed effects vary strongly with receiver and are ranked by receiver-local output sensitivity across Qwen3-8B and Mistral-7B, multiple depths, and three disjoint primary-depth C4 buckets.

This does not make pullback-Fisher geometry or generic state dependence novel. FishBack and state-dependent steering already occupy that conceptual ground. The paper therefore uses Fisher geometry as established machinery and claims novelty only for the natural full-dose crossed-receiver measurement and its controlled empirical result.

The result also stops short of a stronger notion of computation reuse. Low receiver disturbance does not prove that an exact donor MLP output preserved the causal function it performed natively. Functional preservation is explicitly left open. This boundary separates the workshop result from nearby work on function vectors and reusable causal interfaces, including Hidden APIs.

The full-dose result complements Grant et al.: representational divergence need not determine behavioral damage, whereas the present score is explicitly output-aware. Strong full-dose ranking is therefore not evidence that transplanted hidden states remain on-manifold.
