# Data provenance and redistribution boundary

## What is included

The public artifact contains:

1. **Frozen Pythia confirmatory token IDs**: 512 sequences of 64 token IDs plus next-token IDs, derived from the held-out C4 corpus B used by the experiment. Raw source text is not included.
2. **Frozen external-scope token IDs**: the exact 512-document token windows for GPT-2, OPT-125M, and Qwen2.5-0.5B. The original balanced pool contained 256 WikiText-derived and 256 C4-derived documents. To keep source licenses separable, token arrays are stored under `inputs/external_scope/wikitext/` and `inputs/external_scope/c4/`; `COMMON_SOURCE_MAP.csv` reconstructs the original shuffled row order without containing document text. Its `source_index_in_original_frozen_list` field is an index recorded in the original frozen source list, not a claim of a globally stable row number in the upstream dataset.
3. **Derived experimental outputs**: numerical activations/metrics, pair-level transplant statistics, summaries, and figures needed to verify the manuscript.

## What is intentionally not included

- no pretrained model weights;
- no full third-party datasets;
- no full raw C4 web documents;
- no full raw WikiText documents;
- no Git history or personal account metadata.

The raw-text file that existed in the original Kaggle execution archive was removed from the public artifact. Its original corpus SHA-256 remains in the frozen integrity metadata as provenance, but the raw text itself is not redistributed.

Short C4 excerpts from Pythia development material are retained only as legacy auditable material; the paper does not use those excerpts. No complete source document is packaged, and the artifact claims no ownership of the excerpts.

## Source-specific terms

- C4: ODC-BY; additionally subject to Common Crawl terms of use.
- WikiText: the current repository top-level metadata tags CC BY-SA 3.0 and GFDL, while its dataset-card text states CC BY-SA 4.0; this artifact conservatively preserves attribution and treats applicable upstream terms as controlling.
- OPT-generated outputs are provided strictly for non-commercial research/review use consistent with the OPT-175B license restrictions.

See `THIRD_PARTY_NOTICES.md` for model licenses and attribution.


## C4 Qwen3-8B and Mistral-7B ordinary-matrix study

The 7B/8B ordinary-transplant matrices use a separately sampled deterministic C4 validation pool. The public artifact does not redistribute the raw selected web documents. It retains:

- the SHA-256 of the complete selected raw-document pool;
- the hashes of the 64 documents used by each reported model;
- derived pair-level transplant metrics and summary statistics;
- the frozen selection and analysis protocol.

This is sufficient for numerical verification of the manuscript from frozen outputs. Full model-level regeneration requires re-accessing C4 under its upstream terms and applying the deterministic selection rule recorded in `results/fresh_c4_qwen3_8b_mistral7b/FRESH_C4_PROTOCOL.json`.

## Physical crossed-receiver outputs

The crossed-receiver experiments (protocol `RECEIVER_CAUSAL_T4X2_V3`, run 2026-08-27) provide derived numerical outputs from the deterministic C4 validation protocol used by `KAGGLE_T4X2_receiver_causal_replication_V3.ipynb`.

The public artifact includes:

- six primary row-level crossed-receiver CSVs for Qwen3-8B and Mistral-7B-v0.3 across C4 buckets 1/2/3;
- one 256-context Mistral complete-pair matrix used as a larger-scale ordinary-transplant check;
- compact run configuration and stage summaries;
- the successful execution notebook and CPU-only recomputation scripts.

The artifact does not redistribute pretrained weights, Hugging Face caches, `native_cache.pt`, or full raw C4 documents. Those large runtime caches are not needed to verify the paper statistics.


## Final receiver-transformation outputs

The 96×8 Qwen3-8B and Mistral-7B control panels provide derived numerical outputs. These include row-level intervention metrics, displacement/receiver identifiers, layerwise causal-effect summaries, held-out receiver-map summaries, bootstrap comparisons, finite-difference/Richardson diagnostics, and publication figures.

Large Qwen hidden-state memory maps generated during execution are not included because individual files exceed ordinary Git hosting limits and are not needed to verify the numerical claims reported in the paper. No raw C4 documents or pretrained model weights are redistributed.
