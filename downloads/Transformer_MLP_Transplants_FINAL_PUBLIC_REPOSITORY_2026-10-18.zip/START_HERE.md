# Start here

This repository supports **“Transformer MLP Transplants Depend on the Receiving State.”**

## The core experiment

For a natural origin pair, define

```text
delta_u = donor_update - origin_host_update
```

Then physically inject that **same vector** into multiple alternative receiver states:

```text
receiver_update -> receiver_update + delta_u
```

Only the receiver changes. The experiment recomputes both the exact full-dose next-token KL and the receiver-local Fisher score for every receiver.

Across Qwen3-8B and Mistral-7B, the receiver-local score strongly ranks which receivers are affected most, across three disjoint C4 buckets and multiple depths.

## Direction of the causal effect

The paper also keeps the full downstream causal-effect vector instead of reducing every intervention to KL. Identical displacements rapidly acquire different directions in different receivers. A low-rank map learned specifically for one receiver predicts held-out displacement effects better than a global or wrong-receiver map in both model families.

## Run this first

```bash
python -m pip install -r requirements.txt
python analysis/audit_final_public_results.py
```

Then inspect:

- `results/physical_crossing_v3/primary/` for the six primary crossed matrices;
- `results/receiver_transformation_v1/` for the final control and held-out map analyses;
- `paper/NewInML_2026/` and `paper/MusIML_2026/` for the public manuscript source.

## Important boundaries

- Pullback-Fisher geometry is used as established machinery, not claimed as new.
- The residual-rank analysis is post hoc.
- The receiver-transformation result captures a reusable component, not a full deterministic law.
- The FP16 finite-difference Fisher scores are ranking diagnostics. The exact FP32 downstream-suffix JVP audit (`results/fp32_suffix_jvp_audit/`) closes truncation error on 16 tested directions per model; it is not a full-model FP32 JVP.
