# Public release synchronization

This archive is synchronized with the first public 2026 workshop versions of **Transformer MLP Transplants Depend on the Receiving State**.

- Public artifact revision: `2026-10-18`
- Author: Muhammed Nehan, Ajman University
- Workshops: NewInML 2026 and MusIML 2026 at NeurIPS 2026
- Direct-crossing protocol: `RECEIVER_CAUSAL_T4X2_V3`
- Primary crossed-receiver models/layers: Mistral-7B-v0.3 layer 12; Qwen3-8B layer 14
- Primary C4 crossed buckets: `B1, B2, B3`
- Displacements per crossed stage: `512`
- Receivers/displacement: `16` for B1; `32` for B2/B3
- Final control/receiver-map panel: `96` displacements × `8` receivers/model
- Held-out receiver-map split: `72` train / `24` test displacements
- Receiver-map PCA rank: `16`
- Centered-FD epsilon: `0.075`

## What changed from the August artifact

The public release retains all frozen August evidence and adds:

1. stronger control-panel predictors (AtP top-token, AtP margin, relative norm, receiver alignment, equal-norm physical control);
2. layerwise causal-effect trajectories for Qwen3-8B and Mistral-7B;
3. held-out receiver-specific map evaluation with global and wrong-receiver controls;
4. displacement-clustered uncertainty for the transformation curves and final-layer comparisons;
5. rank-KL additive variance decomposition across all six primary crossed matrices;
6. final NewInML and MusIML public paper source, appendices, checklist, and compiled PDFs.

## 2026-10-18 synchronization

- Paper sources and PDFs replaced by the final public NewInML and MusIML versions (shared body, appendices A–E, full NeurIPS checklist).
- Added the exact FP32 downstream-suffix JVP audit (`results/fp32_suffix_jvp_audit/`, `notebooks/kaggle_2xT4_exact_fp32_suffix_jvp_audit.ipynb`) and its verification script.
- Added `analysis/make_paper_figures.py`, `analysis/derived_stats.py`, `analysis/verify_fp32_suffix_jvp_audit.py`, and `results/derived/`.
- The full-model FP32 notebook (`notebooks/optional_exact_fp32_jvp_audit.ipynb`) was not executed; the reported numerical audit is the downstream-suffix variant.
- Regenerated `checksums/SHA256SUMS.txt`.
