# Compute disclosure: physical crossed-receiver run (protocol `RECEIVER_CAUSAL_T4X2_V3`)

The crossed-receiver run used a Kaggle session with **two NVIDIA Tesla T4 GPUs (16 GB VRAM each)**. Models were loaded in FP16 with Accelerate sharding using `device_map="balanced"` and a 12,000 MiB per-GPU memory cap. Gradients were disabled; crossed interventions used 64-token contexts and pair batch 4.

The preserved run contains **12 physical crossed-receiver stages**: four bucket-1 depths for each of Mistral-7B-v0.3 and Qwen3-8B, plus bucket-2 and bucket-3 primary-depth replications for both models. Across those stages, the saved summaries record **131,072 physical crossed-receiver interventions**. The run also contains the **65,280-pair Mistral primary-depth full-core** stage.

Instrumented successful-stage runtimes in `ALL_STAGE_SUMMARIES.csv` sum to **631.3 minutes = 10.52 hours of wall-clock stage time**:

- physical crossed-receiver stages: **437.8 minutes = 7.30 hours**;
- Mistral 65,280-pair full-core stage: **193.4 minutes = 3.22 hours**.

Because each 7B--8B model is sharded across both T4s, counting both devices for the full measured interval gives approximately **21 T4 GPU-hours**. The observed end-to-end successful notebook execution was approximately **10--12 hours**, consistent with the instrumented 10.52-hour stage total once model loading, native-state caching, and ordinary session/notebook overhead are included.

This is the compute for the run that produced the paper's physical crossed-receiver evidence. It is **not** the total compute consumed by the research process: exploratory development, failed engineering attempts, the ordinary 64-by-63 Qwen/Mistral matrix study (`COMPUTE.md`), and Pythia/small-model scope experiments used additional compute and are not included in the 10--12 hour figure.

The row-level public artifact is CPU-verifiable; no GPU is needed to recompute the reported correlations, residual analyses, or figures from the saved CSVs.


## Final 96-by-8 receiver-transformation panels

The public release additionally includes one 96-displacement × 8-receiver panel per large model at the primary layer (Qwen3-8B layer 14; Mistral-7B-v0.3 layer 12). These runs used the same Kaggle T4 ×2 hardware class with FP16 model weights. They collect stronger baselines, equal-norm physical controls, downstream final-token causal trajectories, and the held-out receiver-map evaluation.

The receiver-map analysis is forward-pass based and streams downstream final-token differences to CPU-backed storage; it does not train or fine-tune model parameters. Exact end-to-end wall-clock time for these two final panels was not separately instrumented in a way suitable for a precise public compute claim, so this repository does not invent a runtime estimate. The frozen notebooks and outputs are provided under `notebooks/` and `results/receiver_transformation_v1/`.


## Exact FP32 downstream-suffix JVP audit

Run in a Kaggle session with two NVIDIA T4 GPUs (16 GB each): the FP16 model (Accelerate `device_map="balanced"`) produces the natural states for 16 cases per model; the pruned downstream suffix is then converted to FP32 (TF32 disabled) and split across both GPUs. The notebook did not record runtime, so none is reported.
