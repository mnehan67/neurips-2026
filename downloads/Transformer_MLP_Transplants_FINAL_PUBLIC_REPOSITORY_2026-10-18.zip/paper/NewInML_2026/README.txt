NewInML 2026 public paper source

Compile main.tex with pdflatex -> bibtex -> pdflatex -> pdflatex.
main.tex is the workshop wrapper; body.tex, appendix.tex, and checklist.tex are the shared
scientific text (identical in the NewInML and MusIML trees). neurips_2026.sty is the official,
unmodified NeurIPS 2026 style. Figures are regenerated from frozen outputs by
analysis/make_paper_figures.py (Figure 1 is TikZ in fig1_design.tex).

Numerical audit: the crossed experiments use FP16 finite-difference Fisher scores. The exact
FP32 downstream-suffix JVP audit (results/fp32_suffix_jvp_audit/) closes finite-difference
truncation error on 16 tested directions per model; it is not a full-model FP32 JVP and does
not make the FP16 scores numerically exact (paper Appendix D.12).
