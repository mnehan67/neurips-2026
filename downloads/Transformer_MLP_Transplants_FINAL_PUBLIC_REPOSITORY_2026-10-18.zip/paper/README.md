# Public paper source

This directory contains the synchronized public source for **“Transformer MLP Transplants Depend on the Receiving State.”**

- `NewInML_2026/` — full NewInML public source, official NeurIPS 2026 style, appendices, and checklist.
- `MusIML_2026/` — full MusIML public source with identical scientific content.
- `Transformer_MLP_Transplants_NewInML_2026.pdf` — compiled NewInML public paper.
- `Transformer_MLP_Transplants_MusIML_2026.pdf` — compiled MusIML public paper.

Both trees compile from `main.tex` (wrapper) plus the shared `body.tex`, `appendix.tex`, and `checklist.tex`. The two source trees differ only in workshop wrapper/footer metadata.

`NewInML_2026_submission/` and `MusIML_2026_submission/` build the same paper as two documents: `main.tex` (main text, references, and NeurIPS checklist; `*_SUBMISSION.pdf`) and `supplement.tex` (Appendices A–E; `*_SUPPLEMENT.pdf`). The supplement continues the main paper's table, figure, and equation numbering, so all numbers agree with the full paper. The scientific body, references, appendices, figures, and checklist are synchronized.

The manuscript is non-anonymous and lists:

**Muhammed Nehan**  
Ajman University  
202410365@ajmanuni.ac.ae
