MusIML 2026 submission source for Transformer MLP Transplants Depend on the Receiving State.

main.tex        -> submission PDF: main text (8 pages) + references + full NeurIPS checklist.
supplement.tex  -> supplementary PDF: Appendices A-E + references.

The scientific text is identical to the full paper. References between the main text and the
appendix are written out with their final numbers, and the supplement continues the main paper's
table/figure/equation numbering, so both PDFs compile independently and agree with each other.

Compile each with: pdflatex -> bibtex -> pdflatex -> pdflatex (main.tex, then supplement.tex).
