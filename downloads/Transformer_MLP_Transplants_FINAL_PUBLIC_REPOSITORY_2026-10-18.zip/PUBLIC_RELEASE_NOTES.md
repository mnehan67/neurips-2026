# Release notes — public release 2026-10-18

Public reproducibility artifact for **Transformer MLP Transplants Depend on the Receiving State**
(Muhammed Nehan, Ajman University; NewInML 2026 and MusIML 2026 workshops at NeurIPS 2026).

## Contents

- Physical crossed-receiver experiments for Qwen3-8B and Mistral-7B-v0.3 (buckets B1–B3, four depths) and the 65,280-pair Mistral ordinary-transplant matrix (`results/physical_crossing_v3/`).
- 96×8 control panels with attribution-patching, relative-norm, receiver-norm, state-alignment, and physical equal-norm controls; layerwise causal-effect trajectories; held-out receiver-specific maps with displacement-clustered bootstrap and standard-error summaries (`results/receiver_transformation_v1/`).
- Rank-KL additive decomposition across the six primary crossed matrices.
- Ordinary 64×63 transplant matrices with wrong-state, dose, and teacher-forced controls (`results/fresh_c4_qwen3_8b_mistral7b/`).
- Six independently pretrained Pythia-70M runs under ordinary transplants (`results/pythia_six_run/`).
- Exact FP32 downstream-suffix JVP audit on 16 frozen control-panel cases per model, with an FP16-vs-FP32 comparison (`results/fp32_suffix_jvp_audit/`).
- Descriptive spread statistic (`results/derived/`).
- NewInML and MusIML paper sources, appendices, NeurIPS checklist, and PDFs (`paper/`).
- CPU audit, figure-generation, and verification scripts (`analysis/`); execution notebooks (`notebooks/`); SHA-256 manifest (`checksums/`).

## Not included

- pretrained model weights;
- full raw C4/WikiText documents;
- Qwen hidden-state mmap files larger than normal Git hosting limits;
- temporary partial CSV duplicates and transient Pythia-JVP logs from the Mistral control-panel notebook;
- exploratory experiments not reported in the paper.

`notebooks/optional_exact_fp32_jvp_audit.ipynb` (full-model FP32 on one 80 GB GPU) was not executed and is not part of the reported evidence. The Qwen3-8B control-panel artifact contains the frozen bootstrap and standard-error summaries but not per-held-out-displacement map scores.

See `VERSION.md` for the dated version history.
