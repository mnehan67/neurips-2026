# Updating the current `newinml-7402` repository

This archive is designed to **replace the contents of the current repository**, not to be nested inside it.

## Recommended update

1. Keep the existing repository URL if you want the PDF's current artifact link to remain valid.
2. Replace the repository contents with the contents of this archive.
3. Do not keep any other `paper/` directory or root README alongside these files; this archive is complete.
4. Verify the upload by running:

```bash
python -m pip install -r requirements.txt
python analysis/audit_final_public_results.py
sha256sum -c checksums/SHA256SUMS.txt
```

5. Confirm that the repository landing page begins with **Transformer MLP Transplants Depend on the Receiving State** and names Muhammed Nehan / Ajman University.

## If you move the repository to a named public GitHub URL

The current paper source still points to the existing frozen artifact URL:

`https://anonymous.4open.science/r/newinml-7402/`

If you replace that with a permanent GitHub/archival URL, update `\artifacturl` in both:

- `paper/NewInML_2026/main.tex`
- `paper/MusIML_2026/main.tex`

and the explicit URLs in each `checklist.tex`, then recompile both PDFs before submission/public release.

## What not to upload separately

Do not add the large Qwen `.mmap` runtime arrays unless you use Git LFS or another large-file store. They are not required for the reported frozen-output audits and exceed ordinary Git hosting limits.
