#!/usr/bin/env python3
"""Regenerate the publication-style receiver-transformation plots from frozen summary tables."""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/"results"/"receiver_transformation_v1"
OUT=ROOT/"figures"
OUT.mkdir(exist_ok=True)

LABELS={
    "gain_only":"Gain only",
    "global_map":"Global map",
    "identity":"Identity",
    "receiver_map":"Receiver-specific map",
    "wrong_receiver_map":"Wrong-receiver map",
}
TITLES={"qwen3_8b":"Qwen3-8B (Layer 14)","mistral_7b":"Mistral-7B (Layer 12)"}
for model in ["qwen3_8b","mistral_7b"]:
    d=pd.read_csv(BASE/model/"receiver_map_clustered_se.csv")
    fig,ax=plt.subplots(figsize=(8,5))
    for method,g in d.groupby("method",sort=False):
        g=g.sort_values("downstream_layer")
        x=g["downstream_layer"].to_numpy()
        y=g["mean_cosine"].to_numpy()
        se=g["se"].to_numpy()
        line=ax.plot(x,y,marker="o",label=LABELS.get(method,method))[0]
        ax.fill_between(x,y-se,y+se,alpha=0.15,color=line.get_color())
    ax.axhline(0,linewidth=.8,color="0.65")
    ax.set_xlabel("Downstream layer")
    ax.set_ylabel("Held-out cosine prediction")
    ax.set_title(TITLES[model])
    ax.legend(fontsize=8)
    fig.tight_layout()
    path=OUT/f"{model}_receiver_transformation_regenerated.png"
    fig.savefig(path,dpi=300)
    plt.close(fig)
    print("Wrote",path.relative_to(ROOT))
