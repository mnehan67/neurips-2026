"""Context-disjoint LORO robustness audit from frozen Pythia pair outputs.

This is a secondary, post-hoc robustness audit. It does not change the
frozen primary endpoint. For each of 10 deterministic 50/50 splits of the 256
common host identities, the ridge predictor is trained on five pretrained runs
using only the training-half hosts and evaluated on the held-out pretrained run
using only the disjoint test-half hosts.

No model inference is performed.
"""
from pathlib import Path
import tempfile, zipfile
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge

ROOT = Path(__file__).resolve().parents[1]
ZIP = ROOT / 'results' / 'pythia_six_run' / 'pythia_six_run_full_outputs.zip'
OUT = ROOT / 'results' / 'secondary_audits'
BASE_SEED = 20260820
N_SPLITS = 10

FEATURES = {
    'magnitude_only': ['log_update_distance'],
    'source_geometry': [
        'log_update_distance', 'log_state_distance',
        'normalized_nonlinear_residual', 'tangent_alignment'
    ],
    'source_plus_downstream': [
        'log_update_distance', 'log_state_distance',
        'normalized_nonlinear_residual', 'tangent_alignment',
        'log_downstream_Q'
    ],
}


def load_pairs():
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        with zipfile.ZipFile(ZIP) as z:
            name = next(n for n in z.namelist() if n.endswith('/CONFIRMATORY_B_PAIRS.csv'))
            z.extract(name, td)
        q = pd.read_csv(td / name)
    q = q[q.condition.eq('knn_5')].copy()
    q['log_update_distance'] = np.log1p(q.exact_update_displacement.clip(lower=0))
    q['log_state_distance'] = np.log1p(q.exact_state_displacement.clip(lower=0))
    q['log_downstream_Q'] = np.log1p(q.downstream_fisher_Q_full.clip(lower=0))
    q['target'] = np.log1p(q.KL.clip(lower=0))
    return q


def main():
    q = load_pairs()
    host_ids = np.array(sorted(q.source_index.unique()))
    assert len(host_ids) == 256, f'Expected 256 common hosts, found {len(host_ids)}'
    repos = sorted(q.repo.unique())
    rows = []

    for split_id in range(N_SPLITS):
        rng = np.random.default_rng(BASE_SEED + split_id)
        perm = rng.permutation(host_ids)
        train_ids = set(perm[: len(perm)//2])
        test_ids = set(perm[len(perm)//2 :])

        for held in repos:
            train0 = q[q.repo.ne(held) & q.source_index.isin(train_ids)].copy()
            test0 = q[q.repo.eq(held) & q.source_index.isin(test_ids)].copy()
            for name, fs in FEATURES.items():
                train = train0[fs + ['target']].replace([np.inf, -np.inf], np.nan).dropna()
                test = test0[fs + ['target']].replace([np.inf, -np.inf], np.nan).dropna()
                model = make_pipeline(StandardScaler(), Ridge(alpha=1.0))
                model.fit(train[fs], train.target)
                pred = model.predict(test[fs])
                rows.append({
                    'split_id': split_id,
                    'split_seed': BASE_SEED + split_id,
                    'heldout_repo': held,
                    'feature_set': name,
                    'n_train': len(train),
                    'n_test': len(test),
                    'spearman': float(spearmanr(pred, test.target).statistic),
                })

    OUT.mkdir(parents=True, exist_ok=True)
    out = pd.DataFrame(rows)
    out.to_csv(OUT / 'CONTEXT_DISJOINT_LORO_BY_SPLIT_RUN.csv', index=False)
    wide = out.pivot_table(index=['split_id','heldout_repo'], columns='feature_set', values='spearman').reset_index()
    wide['downstream_increment'] = wide['source_plus_downstream'] - wide['source_geometry']
    wide.to_csv(OUT / 'CONTEXT_DISJOINT_LORO_WIDE.csv', index=False)

    summary = pd.DataFrame([{
        'n_splits': N_SPLITS,
        'n_run_split_evaluations': len(wide),
        'median_magnitude_only': float(wide['magnitude_only'].median()),
        'median_source_geometry': float(wide['source_geometry'].median()),
        'median_source_plus_downstream': float(wide['source_plus_downstream'].median()),
        'median_downstream_increment': float(wide['downstream_increment'].median()),
        'positive_downstream_increments': int((wide['downstream_increment'] > 0).sum()),
    }])
    summary.to_csv(OUT / 'CONTEXT_DISJOINT_LORO_SUMMARY.csv', index=False)
    print(summary.to_string(index=False))


if __name__ == '__main__':
    main()
