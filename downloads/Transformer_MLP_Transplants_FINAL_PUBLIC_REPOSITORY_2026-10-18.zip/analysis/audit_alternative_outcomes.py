"""Alternative-outcome robustness from frozen Pythia pair outputs.

This secondary, post-hoc secondary audit checks whether Q_down is informative for
outcomes other than the exact KL from which its local Fisher interpretation is
derived: absolute observed-token NLL change and top-1 flip. It also repeats LORO
prediction for absolute NLL change.

No model inference is performed.
"""
from pathlib import Path
import tempfile, zipfile
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import roc_auc_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge

ROOT = Path(__file__).resolve().parents[1]
ZIP = ROOT / 'results' / 'pythia_six_run' / 'pythia_six_run_full_outputs.zip'
OUT = ROOT / 'results' / 'secondary_audits'

SOURCE_FEATURES = [
    'log_update_distance', 'log_state_distance',
    'normalized_nonlinear_residual', 'tangent_alignment'
]
DOWNSTREAM_FEATURES = SOURCE_FEATURES + ['log_downstream_Q']


def load_pairs():
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        with zipfile.ZipFile(ZIP) as z:
            name = next(n for n in z.namelist() if n.endswith('/CONFIRMATORY_B_PAIRS.csv'))
            z.extract(name, td)
        q = pd.read_csv(td / name)
    q = q[q.condition.eq('knn_5')].copy()
    q['log_update_distance'] = np.log1p(q.exact_update_displacement.clip(lower=0))
    q['log_state_distance'] = np.log1p(q.exact_state_displacement.clip(lower=0))
    q['log_downstream_Q'] = np.log1p(q.downstream_fisher_Q_full.clip(lower=0))
    q['abs_nll_change'] = q.NLL_delta.abs()
    q['target_abs_nll'] = np.log1p(q.abs_nll_change)
    return q


def main():
    q = load_pairs()
    OUT.mkdir(parents=True, exist_ok=True)

    run_rows = []
    for repo, g in q.groupby('repo'):
        run_rows.append({
            'repo': repo,
            'n': len(g),
            'rho_Q_to_abs_NLL_change': float(spearmanr(g.downstream_fisher_Q_full, g.abs_nll_change).statistic),
            'roc_auc_Q_to_top1_flip': float(roc_auc_score(g.top1_flip, g.downstream_fisher_Q_full)),
        })
    runs = pd.DataFrame(run_rows)
    runs.to_csv(OUT / 'ALTERNATIVE_OUTCOMES_BY_RUN.csv', index=False)

    loro_rows = []
    for held in sorted(q.repo.unique()):
        train0 = q[q.repo.ne(held)]
        test0 = q[q.repo.eq(held)]
        for name, fs in {
            'source_geometry': SOURCE_FEATURES,
            'source_plus_downstream': DOWNSTREAM_FEATURES,
        }.items():
            train = train0[fs + ['target_abs_nll']].replace([np.inf, -np.inf], np.nan).dropna()
            test = test0[fs + ['target_abs_nll']].replace([np.inf, -np.inf], np.nan).dropna()
            model = make_pipeline(StandardScaler(), Ridge(alpha=1.0))
            model.fit(train[fs], train.target_abs_nll)
            pred = model.predict(test[fs])
            loro_rows.append({
                'heldout_repo': held,
                'feature_set': name,
                'n_train': len(train),
                'n_test': len(test),
                'spearman_abs_NLL_change': float(spearmanr(pred, test.target_abs_nll).statistic),
            })
    loro = pd.DataFrame(loro_rows)
    loro.to_csv(OUT / 'ALTERNATIVE_OUTCOMES_LORO.csv', index=False)
    wide = loro.pivot(index='heldout_repo', columns='feature_set', values='spearman_abs_NLL_change').reset_index()
    wide['downstream_increment'] = wide['source_plus_downstream'] - wide['source_geometry']
    wide.to_csv(OUT / 'ALTERNATIVE_OUTCOMES_LORO_WIDE.csv', index=False)

    summary = pd.DataFrame([{
        'median_rho_Q_to_abs_NLL_change': float(runs.rho_Q_to_abs_NLL_change.median()),
        'median_roc_auc_Q_to_top1_flip': float(runs.roc_auc_Q_to_top1_flip.median()),
        'median_loro_source_geometry_abs_NLL': float(wide.source_geometry.median()),
        'median_loro_source_plus_downstream_abs_NLL': float(wide.source_plus_downstream.median()),
        'median_loro_downstream_increment_abs_NLL': float(wide.downstream_increment.median()),
        'positive_loro_downstream_increments': int((wide.downstream_increment > 0).sum()),
    }])
    summary.to_csv(OUT / 'ALTERNATIVE_OUTCOMES_SUMMARY.csv', index=False)
    print(summary.to_string(index=False))


if __name__ == '__main__':
    main()
