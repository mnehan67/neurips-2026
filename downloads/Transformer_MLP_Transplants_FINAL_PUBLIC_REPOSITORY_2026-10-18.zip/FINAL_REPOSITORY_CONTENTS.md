# Repository contents

## Experimental evidence

- six primary crossed-receiver row-level tables (Qwen3-8B layer 14, Mistral-7B-v0.3 layer 12; buckets B1–B3) and the B1 depth sweep;
- the 65,280-pair Mistral ordinary-transplant matrix;
- Qwen3-8B and Mistral-7B 96×8 control panels, layerwise causal-effect trajectories, held-out receiver-map benchmarks, and bootstrap / clustered-SE summaries (per-held-out-displacement map scores are available for Mistral-7B only);
- rank-KL displacement/receiver additive decomposition for all six primary crossed matrices;
- ordinary 64×63 transplant matrices with depth, dose, wrong-state, and teacher-forced controls;
- six independently pretrained Pythia-70M runs;
- exact FP32 downstream-suffix JVP audit outputs with the FP16-vs-FP32 comparison (paper Appendix D.12.2);
- external-scope tests and secondary audits.

## Code, notebooks, and paper

- CPU scripts that recompute and audit the reported statistics, regenerate every data figure of the paper, compute the spread statistic, and verify the numerical audit;
- the Kaggle T4×2 execution notebooks for the crossed-receiver run, the control panels, and the FP32 suffix-JVP audit;
- the optional full-model exact-FP32 JVP notebook, not executed and not part of reported evidence;
- NewInML and MusIML paper sources, appendices, official NeurIPS checklist, and PDFs;
- author, license, citation, provenance, and compute metadata;
- SHA-256 manifest.

## Not included

Temporary partial CSV duplicates, transient Pythia-JVP logs from the Mistral control-panel notebook, large Qwen `.mmap` arrays, model weights, and raw C4/WikiText documents. None is required to verify the paper's reported frozen-output statistics.
